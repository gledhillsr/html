/*
 * BTN.java
 *
 * Created on December 12, 2002, 1:43 PM
 */

import java.sql.*;
import java.net.*;

/**
 *
 * @author  Gledhill
 */
public class BTN {
    static boolean DEBUG = false;
    String btn;
    long LastUpdated;    
    String Location;
    String Division;
    String Department;
    String AMC;
    String Description;
    long ContractExpDate;
    double Cost;
    String Review;
    String CustomerID;

    private boolean exceptionError;
/**** database fields *********************************/    
/*************************************/    
    
    /** Creates a new instance of BTN */
    public BTN() {
        btn = "";
        LastUpdated = 0;    
        Location = "";
        Division = "";
        Department = "";
        AMC = "000000000000";
        Description = "";
        ContractExpDate = 0;
        Cost = 0.0;
        Review = "";
        CustomerID = "";
        exceptionError = false;
    }
    public BTN(String Btn, String cust, String loc, long lastUpdated,double cost) {
        btn = Btn;
        LastUpdated = lastUpdated;    
        Location = loc;
        Division = "";
        Department = "";
        AMC = "000000000000";
        Description = "";
        ContractExpDate = 0;
        Cost = cost;
        Review = "";
        CustomerID = cust;
        exceptionError = false;
    }
    public boolean read(ResultSet results) {
	exceptionError = false;
        btn = DBAccess.readString(results,"BTN",exceptionError);
        String str = DBAccess.readString(results,"LastUpdated",exceptionError);
        LastUpdated = 0;
        try {
            LastUpdated = Long.parseLong(str);
        } catch (Exception e) { }
        Location = DBAccess.readString(results,"Location",exceptionError);
        Division = DBAccess.readString(results,"Division",exceptionError);
        Department = DBAccess.readString(results,"Department",exceptionError);
        AMC = DBAccess.readString(results,"AMC",exceptionError);
        Description = DBAccess.readString(results,"Description",exceptionError);
        ContractExpDate = 0;
        str = DBAccess.readString(results,"ContractExpDate",exceptionError);
        try {
            ContractExpDate = Long.parseLong(str);
        } catch (Exception e) { }
        Cost = DBAccess.readDouble(results,"Cost",exceptionError);
        Review = DBAccess.readString(results,"Review",exceptionError);
        CustomerID = DBAccess.readString(results,"CustomerID",exceptionError);
        return exceptionError;
    }
    public String getBTN()          {        return btn;    }
    public long getLastUpdated()    {      return LastUpdated;    }
    public String getLocation()     {      return Location;    }
    public String getDivision()     {      return Division;    }
    public String getDepartment()   {      return Department;    }
    public String getAMC()          {      return AMC;    }
    public String getDescription()  {      return Description;    }
    public long getContractExpDate(){   return ContractExpDate;    }
    public double getCost()         {      return Cost;    }
    public String getReview()       {      return Review;    }
    public String getCustomerID()   {      return CustomerID;    }

    public void setLastUpdated(long millis) { LastUpdated = millis; }
    public void setCost(double amt)         { Cost = amt;    }
    public void setAMC(String str)          { AMC  = str;    }
//-----------------------------------------------------
// getSQLUpdateString
//-----------------------------------------------------
    public String getSQLUpdateString() {
    String qryString = "UPDATE btn SET " +
        " LastUpdated=\"" + LastUpdated +
        "\", Location=\"" + Location +
        "\", Division=\"" + Division +
        "\", Department=\"" + Department +
        "\", AMC=\"" + AMC +
        "\", Description=\"" + Description +
        "\", ContractExpDate=\"" + ContractExpDate +
        "\", Cost=\"" + Cost +
        "\", Review=\"" + Review +
        "\", CustomerID=\"" + CustomerID +
        "\" WHERE BTN=\"" + btn + "\"";
    if(DEBUG)
        System.out.println(qryString);
    return qryString;
    }

//-----------------------------------------------------
// getSQLSelectBTNString
//-----------------------------------------------------
    public static String getSQLSelectBTNString(String btn) {
        String qryString= "SELECT * FROM btn WHERE BTN=\""+btn+"\""; //select 1 btn
        if(DEBUG)
            System.out.println(qryString);
        return qryString;
    }
    
//-----------------------------------------------------
// getSQLResetString
//-----------------------------------------------------
    public static String getSQLResetString() {
        String qryString= "SELECT * FROM btn ORDER BY BTN"; //sort by default key
        if(DEBUG)
            System.out.println(qryString);
        return qryString;
    }
    
//-----------------------------------------------------
// getSQLInsertString
//-----------------------------------------------------
    public String getSQLInsertString() {
        String qryString = "INSERT INTO btn "+
        " Values(\""+ btn + 
        "\",\"" + LastUpdated +
        "\",\"" + Location + 
        "\",\"" + Division +
        "\",\"" + Department +
        "\",\"" + AMC +
        "\",\"" + Description +
        "\",\"" + ContractExpDate +
        "\",\"" + Cost +
        "\",\"" + Review +
        "\",\"" + CustomerID + 
        "\")" ;
        if(DEBUG)
            System.out.println(qryString);
        return qryString;
    }

//-----------------------------------------------------
// getSQLDeleteString
//-----------------------------------------------------
    public String getSQLDeleteString() {
        int i;
        String qryString = "DELETE FROM btn WHERE BTN=\""+btn+"\"";
        if(DEBUG)
            System.out.println(qryString);
        return qryString;
    }

    public String toString() {
        return btn;
    }
}
