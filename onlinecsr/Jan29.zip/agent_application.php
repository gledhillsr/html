<?
/********************************************************************/
/* do NOT edit the .php file, because it is a COPY of the .HTM file */
/* so others can use front page as an editor.                       */
/********************************************************************/
?>
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta http-equiv="Content-Language" content="en-us">

<title>Agent Application</title>
<?
  $isForm=1;
  $cur_page="agent_application";
  require("config.php");
  include($styles_file); 
?>
</head>

<body bgcolor="#FFFFFF" text="#000000" link="#999999" vlink="#990000" alink="#666666"  >

<?
include($header_file); 
?>

<table border="0" cellpadding="0" cellspacing="0" width="100%">
<tr><td valign="top" width="1%"><font face="Arial, Arial, Helvetica">

<p>&nbsp;</p>


<p>
&nbsp;</p>

</font></td><td valign="top" width="24"></td><td valign="top"><font face="Arial, Arial, Helvetica">
<H1><font face="Arial">Agent Information Form</font></H1>
<p align="center"><img src="_themes/blank/blrule.gif" width="600" height="10"></p>
<P>
<font size="4" face="Arial">Please provide us with the following information.&nbsp; 
You may modify this information at a later date.</font></P>

<form method="POST" action="mail.php?frm=application&owner=<? echo $owner; ?>.php">

<BLOCKQUOTE>
</font>

<TABLE>
<TR>
<TD ALIGN="right"><font face="Arial, Arial, Helvetica">
<font face="Arial">
<EM>Name</EM></font></font></TD>
<TD><font face="Arial, Arial, Helvetica">
<font face="Arial">
<INPUT TYPE=TEXT NAME="Contact_FullName" SIZE=35> </font>
</font></TD>
</TR>
<TR>
<TD ALIGN="right"><font face="Arial, Arial, Helvetica">
<font face="Arial">
<EM>Organization</EM></font></font></TD>
<TD><font face="Arial, Arial, Helvetica">
<font face="Arial">
<INPUT TYPE=TEXT NAME="Contact_Organization" SIZE=35> </font>
</font></TD>
</TR>
<TR>
<TD ALIGN="right"><font face="Arial, Arial, Helvetica">
<font face="Arial">
<EM>Street Address</EM></font></font></TD>
<TD><font face="Arial, Arial, Helvetica">
<font face="Arial">
<INPUT TYPE=TEXT NAME="Contact_StreetAddress" SIZE=35> </font>
</font></TD>
</TR>
<TR>
<TD ALIGN="right"><font face="Arial, Arial, Helvetica">
<font face="Arial">
<EM>Address (cont.)</EM></font></font></TD>
<TD><font face="Arial, Arial, Helvetica">
<font face="Arial">
<INPUT TYPE=TEXT NAME="Contact_Address2" SIZE=35> </font>
</font></TD>
</TR>
<TR>
<TD ALIGN="right"><font face="Arial, Arial, Helvetica">
<font face="Arial">
<EM>City</EM></font></font></TD>
<TD><font face="Arial, Arial, Helvetica">
<font face="Arial">
<INPUT TYPE=TEXT NAME="Contact_City" SIZE=35> </font>
</font></TD>
</TR>
<TR>
<TD ALIGN="right"><font face="Arial, Arial, Helvetica">
<font face="Arial">
<EM>State</EM></font></font></TD>
<TD><font face="Arial, Arial, Helvetica">
<font face="Arial">
<INPUT TYPE=TEXT NAME="Contact_State" SIZE=35> </font>
</font></TD>
</TR>
<TR>
<TD ALIGN="right"><font face="Arial, Arial, Helvetica">
<font face="Arial">
<EM>Zip Code</EM></font></font></TD>
<TD><font face="Arial, Arial, Helvetica">
<font face="Arial">
<INPUT TYPE=TEXT NAME="Contact_ZipCode" SIZE=12 MAXLENGTH=12> </font>
</font></TD>
</TR>
<TR>
<TD ALIGN="right"><font face="Arial, Arial, Helvetica">
<font face="Arial">
<EM>Phone</EM></font></font></TD>
<TD><font face="Arial, Arial, Helvetica">
<font face="Arial">
<INPUT NAME="Contact_Phone" SIZE=25 MAXLENGTH=25> </font>
</font></TD>
</TR>
<TR>
<TD ALIGN="right"><font face="Arial, Arial, Helvetica">
<font face="Arial"><em>Cell Phone</em></font></font></TD>
<TD><font face="Arial, Arial, Helvetica">
<font face="Arial">
<INPUT NAME="Contact_Cell" SIZE=25 MAXLENGTH=25></font></font></TD>
</TR>
<TR>
<TD ALIGN="right"><font face="Arial, Arial, Helvetica">
<font face="Arial">
<EM>FAX</EM></font></font></TD>
<TD><font face="Arial, Arial, Helvetica">
<font face="Arial">
<INPUT NAME="Contact_FAX" SIZE=25 MAXLENGTH=25> </font>
</font></TD>
</TR>
<TR>
<TD ALIGN="right"><font face="Arial, Arial, Helvetica">
<font face="Arial">
<EM>E-mail</EM></font></font></TD>
<TD><font face="Arial, Arial, Helvetica">
<font face="Arial">
<INPUT TYPE=TEXT NAME="Contact_Email" SIZE=25> </font>
</font></TD>
</TR>
<TR>
<TD ALIGN="right"><font face="Arial, Arial, Helvetica">
<font face="Arial">
<EM>URL</EM></font></font></TD>
<TD><font face="Arial, Arial, Helvetica">
<font face="Arial">
<INPUT TYPE=TEXT NAME="Contact_URL" SIZE=25 MAXLENGTH=25> </font>
</font></TD>
</TR>
</TABLE><font face="Arial, Arial, Helvetica">
</BLOCKQUOTE>
<P>
<font size="4" face="Arial">Who do we notify in your organization when a client 
subscribes for service?</font></P>
<BLOCKQUOTE>
<P>
</P>
</font><TABLE height="82">
<TR>
<TD height="22"><font face="Arial, Arial, Helvetica">
<p align="right"><font face="Arial">
<EM>Notify Name</EM></font></font></TD>
<TD height="22"><font face="Arial, Arial, Helvetica">
<font face="Arial">
<INPUT NAME="Notify_Name" SIZE=25></font></font></TD>
</TR>
<TR>
<TD ALIGN="right" height="22"><font face="Arial, Arial, Helvetica">
<font face="Arial"><em>Notify E-mail</em></font></font></TD>
<TD height="22"><font face="Arial, Arial, Helvetica">
<font face="Arial">
<INPUT NAME="Notify_Email" SIZE=25></font></font></TD>
</TR>
<TR>
<TD ALIGN="right" height="1"><font face="Arial, Arial, Helvetica">
</font></TD>
<TD height="1"><font face="Arial, Arial, Helvetica">
</font></TD>
</TR>
<TR>
<TD ALIGN="right" height="22"><font face="Arial, Arial, Helvetica">
<font face="Arial"><i>Who should be notified when service is set up?</i></font></font></TD>
<TD height="22"><font face="Arial, Arial, Helvetica">
<font face="Arial">&nbsp;<select size="1" name="Notify_after_set_up">
<option selected>Notify the Agent and the Customer</option>
<option>Notify the Agent Only</option>
</select></font></font></TD>
</TR>
</TABLE><font face="Arial, Arial, Helvetica">
</BLOCKQUOTE>
<P>
<font face="Arial"><font size="4">Please provide the following order information:</font><br>
&nbsp;</font></P>
</font><TABLE width="470">
<TR>
<TD width="225" align="right"><font face="Arial, Arial, Helvetica">
<font face="Arial">
<EM>Which RBOC Agent will you use?</EM></font></font></TD>
<TD width="235"><font face="Arial, Arial, Helvetica">
<font face="Arial"><select size="1" name="RBOC_Agent_select">
<option selected>ONLINE-CSR will select an agent</option>
<option>Never use an agent</option>
<option>Always use the agent listed below*</option>
</select></font></font></TD>
</TR>
</TABLE><font face="Arial, Arial, Helvetica">
<BLOCKQUOTE>
</font><TABLE width="470">
<TR>
<TD width="229" align="right"><font face="Arial, Arial, Helvetica">
<font face="Arial"><i>Fill out this section if you selected&nbsp; </i></font>
</font></TD>
<TD width="231"><font face="Arial, Arial, Helvetica">
<font face="Arial">&nbsp;Always use the agent listed below*</font></font></TD>
</TR>
<TR>
<TD ALIGN="right" width="229"><font face="Arial, Arial, Helvetica">
<font face="Arial"><em>*RBOC Agent (organization)</em></font></font></TD>
<TD width="231"><font face="Arial, Arial, Helvetica">
<font face="Arial">
<INPUT NAME="RBOC_agent" SIZE=25> </font>
</font></TD>
</TR>
<TR>
<TD ALIGN="right" width="229"><font face="Arial, Arial, Helvetica">
<font face="Arial"><em>*RBOC Agent Contact Name</em></font></font></TD>
<TD width="231"><font face="Arial, Arial, Helvetica">
<font face="Arial">
<INPUT NAME="RBOC_agent_contact" SIZE=25></font></font></TD>
</TR>
<TR>
<TD ALIGN="right" width="229"><font face="Arial, Arial, Helvetica">
<font face="Arial"><em>*RBOC Agent E-mail address</em></font></font></TD>
<TD width="231"><font face="Arial, Arial, Helvetica">
<font face="Arial">
<INPUT NAME="RBOC_agent_email" SIZE=25></font></font></TD>
</TR>
<TR>
<TD ALIGN="right" width="229"><font face="Arial, Arial, Helvetica">
<font face="Arial"><em>*RBOC Agent Phone</em></font></font></TD>
<TD width="231"><font face="Arial, Arial, Helvetica">
<font face="Arial">
<INPUT NAME="RBOC_agent_phone" SIZE=25> </font>
</font></TD>
</TR>
</TABLE><font face="Arial, Arial, Helvetica">
<P>
<font face="Arial"><br>
Client Billing and Fees: (You can set different fees for each client, the fees 
contained here are your default rates, if your client signs up online)</font></P>
</font><TABLE>
<TR>
<TD ALIGN="right"><font face="Arial, Arial, Helvetica">
<font face="Arial"><em>Who will bill your clients for ONLINE-CSR service?</em></font></font></TD>
<TD><font face="Arial, Arial, Helvetica">
<font face="Arial"><select size="1" name="Who_bills_client">
<option selected>ONLINE-CSR will bill subscriber</option>
<option>Agent will bill subscriber</option>
<option>Always ask agent</option>
</select> </font>
</font></TD>
</TR>
<TR>
<TD ALIGN="right"><font face="Arial, Arial, Helvetica">
<font face="Arial"><em>Do you want to display this pricing on your customized 
ONLINE-CSR web site? </em></font></font></TD>
<TD><font face="Arial, Arial, Helvetica">
<font face="Arial"><select size="1" name="Display_pricing">
<option selected>Yes</option>
<option>No</option>
</select></font></font></TD>
</TR>
<TR>
<TD ALIGN="right"><font face="Arial, Arial, Helvetica">
<font face="Arial"><em>Set up Fee</em></font></font></TD>
<TD><font face="Arial, Arial, Helvetica">
<font face="Arial">&nbsp;<select size="1" name="Set_up_fee">
<option selected>$200 (agent cost $100)</option>
</select></font></font></TD>
</TR>
<TR>
<TD ALIGN="right"><font face="Arial, Arial, Helvetica">
<font face="Arial"><em>Basic Service </em></font></font></TD>
<TD><font face="Arial, Arial, Helvetica">
<font face="Arial">&nbsp;<select size="1" name="Basic_service_fee">
<option selected>20% Commission</option>
<option>0% Commission</option>
<option>30% Commission</option>
<option>40% Commission</option>
<option>50% Commission</option>
<option>Other</option>
</select></font></font></TD>
</TR>
<TR>
<TD ALIGN="right"><font face="Arial, Arial, Helvetica">
<font face="Arial"><em>Labor Hourly Rate</em></font></font></TD>
<TD><font face="Arial, Arial, Helvetica">
<font face="Arial">&nbsp;<select size="1" name="Labor_rate">
<option selected>$62.50 per hour (20% Commission)</option>
<option>$50 per hour (0% Commission)</option>
<option>$71.50 per hour (30% Commission)</option>
<option>$83.50 per hour (40% Commission)</option>
<option>$100 per hour (50% Commission)</option>
<option>Other</option>
</select></font></font></TD>
</TR>
<TR>
<TD ALIGN="right"><font face="Arial, Arial, Helvetica">
<font face="Arial"><em>Extra CSR updates</em></font></font></TD>
<TD><font face="Arial, Arial, Helvetica">
<font face="Arial">&nbsp;<select size="1" name="CSR_updates">
<option selected>$10 (0% Commission)</option>
<option>$12.50 (20% Commission)</option>
<option>$14.50 (30% Commission)</option>
<option>$16.50 (40% Commission)</option>
<option>$20.00 (50% Commission)</option>
<option>Other</option>
</select></font></font></TD>
</TR>
</TABLE><font face="Arial, Arial, Helvetica">
</font><pre></pre><font face="Arial, Arial, Helvetica">
</BLOCKQUOTE>
<P>
<font face="Arial">Other options:</font></P>
<BLOCKQUOTE>
<P>
<font face="Arial">&nbsp;<BR>
</font>
</P>
</BLOCKQUOTE>
<p><font face="Arial">
<INPUT TYPE=SUBMIT VALUE="Submit Form">
<INPUT TYPE=RESET VALUE="Reset Form"> </font></p>
</FORM>

</font></td></tr></table><table border="0" cellpadding="0" cellspacing="0" width="100%"><tr><td><font face="Arial, Arial, Helvetica">

<p>&nbsp;</p>


<p>
</p>


</font></td></tr></table>

<?
 $isLogin = 1;
 include($footer_file); 
?>

</body>
</html>