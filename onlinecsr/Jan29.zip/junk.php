<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Income</title>
<meta name="GENERATOR" content="Microsoft FrontPage 5.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta name="Microsoft Theme" content="blank 000, default">
<meta name="Microsoft Border" content="tlb, default">
</head>
<body bgcolor="#FFFFFF" text="#000000" link="#999999" vlink="#990000" alink="#666666"><!--msnavigation--><table border="0" cellpadding="0" cellspacing="0" width="100%"><tr><td><!--mstheme--><font face="Arial, Arial, Helvetica">
line 1<br>
<? 
	echo "xyzzy<br>";
?>
line 2<br>


<p align="center">
&nbsp;<img border="0" src="_borders/LOGO%2024.gif" width="307" height="53"><br>
<b><font size="2" color="#666666"><a href="../myweb/index.php">Home</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="index.php">Agents</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="get_started.php">Get Started</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="agent_application.php">Agent Application</a>&nbsp;&nbsp;&nbsp;
<a href="pricing.php">Pricing</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="ONLINE-CSR%20Agent%20Agreement.pdf">Contract</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="Qwest%20LOA.pdf">LOA</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="feedback.php">Feedback</a></font></b></p>

<!--mstheme--></font></td></tr><!--msnavigation--></table><!--msnavigation--><table border="0" cellpadding="0" cellspacing="0" width="100%"><tr><td valign="top" width="1%"><!--mstheme--><font face="Arial, Arial, Helvetica">


<p>&nbsp;</p>


<p>
&nbsp;</p>

<!--mstheme--></font></td><td valign="top" width="24"></td><!--msnavigation--><td valign="top"><!--mstheme--><font face="Arial, Arial, Helvetica">
<p>Income opportunities</p>

<!--mstheme--></font><!--msnavigation--></td></tr><!--msnavigation--></table><!--msnavigation--><table border="0" cellpadding="0" cellspacing="0" width="100%"><tr><td><!--mstheme--><font face="Arial, Arial, Helvetica">

<p>&nbsp;</p>


<p>
<nobr>[&nbsp;<a href="index.php">Home</a>&nbsp;]</nobr></p>


<h5>

Send mail to <a href="mailto:webmaster@online-csr.com">
webmaster@online-csr.com</a> with
questions or comments about this web site.<br>


Copyright � 2002 OnLine-CSR, Inc.<br>


</h5>

<!--mstheme--></font></td></tr><!--msnavigation--></table></body>

</html>