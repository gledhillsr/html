

<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta http-equiv="Content-Language" content="en-us">
<title>Agents Feedback Page</title>
</head>

<body bgcolor="#FFFFFF" text="#000000" link="#999999" vlink="#990000" alink="#666666"  >
<?
/********************************************************************/
/* do NOT edit the .php file, because it is a COPY of the .HTM file */
/* so others can use front page as an editor.                       */
/********************************************************************/
?>
<p>
<?
  $isForm=1;
  $cur_page="archive";
  require("config.php");
  include($styles_file); 
?>
<p>
<?
include($header_file); 
$manager_name = "Archive";
include($box_header_file); 
?>
<form method="POST" action="<? echo $SCRIPT_NAME ?>" name="archive_form">
<h3>Sorry, no Archive records found for <? echo $customer_name; ?>.</h3>
<br><br>
<p align="center">
    <input type="button" value="Return" name="B2" onClick=history.back()>
</form>



<table border="0" cellpadding="0" cellspacing="0" width="100%"><tr><td><font face="Arial, Arial, Helvetica">

<p>&nbsp;</p>


<p>
</p>

</font></td></tr></table>

<?
 $isLogin = 1;
 include($footer_file); 
?>
</body>
</html>