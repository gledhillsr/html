<html>
<head>
	<title>CSR</title>
	<link rel="STYLESHEET" type="text/css" href="includes/styles.css">
</head>

<body background="images/bg1.gif" bgcolor="#080032" marginwidth="0" marginheight="0" topmargin="0" leftmargin="0">
<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td><img src="images/h_1.jpg" width="279" height="303"></td>
		<td align="right" valign="bottom"><img src="images/h_title.gif" width="376" height="38"></td>
	</tr>
	<tr>
		<td bgcolor="#ffffff"><img src="images/00-bit.gif" width="1" height="1"></td>
		<td align="left" bgcolor="#ffffff"><img src="images/00-bit.gif" width="491" height="1"></td>
	</tr>
	<tr>
		<td bgcolor="#05001D"><img src="images/h_2.jpg" width="279" height="142"></td>
		<td width="100%" bgcolor="#000000" align="right" valign="top"><img src="images/00-bit.gif" width="1" height="40"><br>
			<table border="0" cellpadding="0" cellspacing="7">
            	<tr>
					<td colspan="9"><img src="images/00-bit.gif" width="1" height="5"></td>
				</tr>
				<tr>
					<td><a class="nav1" href="login.php">Log In</a></td>
					<td><a class="nav1" href="demo.htm">View Demo</a></td>
					<td><a class="nav1" href="services1.php">Services</a></td>
					<td><a class="nav1" href="Order_service.htm">Order Service</a></td>
					<td><a class="nav1" href="about_us.php">About Us</a></td>
					<td><a class="nav1" href="privacy.htm">Privacy</a></td>
					<td><a class="nav1" href="agent_info.htm">Agents</a></td>
            	</tr>
            </table></td>
	</tr>
	<tr>
		<td><img src="images/h_3.jpg" width="279" height="154"></td>
		<td valign="top" class="homeCopy" width="650"><b>ONLINE-CSR�</b>  Provides a service to business, government and education which allows them 
			to effectively manage their voice and data services.  <b>ONLINE-CSR�</b> is the first web-based application to 
			give clients complete visibility into and control over their telecommunication services.</td>
	</tr>
</table>
<div style="padding: 10px 10px 10px 10px"><a href="http://www.i4.net"><img src="images/i4logo.gif" width="141" height="50" border="0"></a></div>
</body>
</html>
