<?
/********************************************************************/
/* do NOT edit the .php file, because it is a COPY of the .HTM file */
/* so others can use front page as an editor.                       */
/********************************************************************/
?>
<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Pricing</title>
<?
  $cur_page="pricing";
  require("config.php");
  include($styles_file); 
?>
</head>

<body bgcolor="#FFFFFF" text="#000000" link="#999999" vlink="#990000" alink="#666666">
<?
include($header_file);  //note: don't specify "$page_title"
?>

<font face="Arial, Arial, Helvetica">

<table border="0" cellpadding="0" cellspacing="0" width="100%"><tr><td valign="top" width="1%"><font face="Arial, Arial, Helvetica">


<p>&nbsp;</p>


<p>
&nbsp;</p>

</font></td><td valign="top" width="24"></td><td valign="top"><font face="Arial, Arial, Helvetica">
<h2><br>
<font face="Arial" color="#666666">Agent's cost for services provided by
OnLine-CSR, Inc.</font></h2>
<p><font face="Arial">When your clients utilize ONLINE-CSR service you have 
several services you can earn a commission on:<br>
<b>Set up Fees, Basic Service, Labor and Extra CSR Updates </b></font></p>
<p><font face="Arial"><b><a href="Price_sheet.php"><font color="#0000FF">PRICE 
SHEET</font></a><font color="#0000FF">&nbsp;&nbsp; </font></b>View this generic 
Price Quote&nbsp; <b><a href="Price_Quote.doc"><font color="#0000FF">Price Quote</font></a></b>
<i>(Word document)</i></font></p>
<p><font face="Arial">ONLINE-CSR has set an agent buy rate for services.&nbsp; Each 
agent can bill the customer directly, have ONLINE-CSR bill the customer or waive 
all the customer's fees if they order services from the agent, in this case the 
agent will pay for their service out of the proceeds from the sales commission.</font></p>
<p><font face="Arial"><font size="5">Here are the descriptions of each service:</font></font></p>
<p><font face="Arial"><b>SET UP FEES</b> This is the one-time charge to set up 
the customer.&nbsp; This fee is set at $200.00 for all customers and can not be 
waived, raised or lowered.&nbsp; The agents cost is $100.00.</font></p>
<p><font face="Arial"><b>BASIC SERVICE</b> This is the online service that gives 
the client a picture of what they are being billed for by the RBOC and a tool to 
track orders, adds, moves, changes and inquiries. The price is determined by the 
number of CSR's each customer has.&nbsp; If a customer has 500 CSRs, then the agent's 
price is $8.00 per CSR.&nbsp; If a customer only has 4 CSRs the agents price is 
$15.00 per CSR.&nbsp; The basic service pulls CSR's twice a year.&nbsp; Your customer may 
want all CSR's pulled every other month, in this case the cost would increase 
substantially.&nbsp; We suggest a markup of 50%, but each agent has the right to set 
their own price.&nbsp;&nbsp; Click here to view the <a href="Price_sheet.php">
<font color="#0000FF">Pricing Sheet</font>.</a></font></p>
<p><font face="Arial"><b>LABOR</b> Labor is optional. Many times a client will 
have an account manager that is efficient and the need for ONLINE-CSR to follow 
through on an order is not required. We use only senior Account Consultants (AC) 
each with over 20 years RBOC experience.&nbsp; If your client needs some changes made 
on their account, and they are not revenue generating changes, who can they rely 
on to do the work.&nbsp; Disconnects are a prime example, when you place an order for 
a disconnect it is necessary to follow up and make sure the service actually 
gets disconnected. Labor is charged in quarter hour increments.</font></p>
<p><font face="Arial"><b>EXTRA CSR UPDATES</b> After a change has been made on a 
CSR it is highly recommended that another CSR be pulled to replace the outdated 
record. This would not be necessary if your client has a semi-annual update 
within the next month or so.&nbsp; You can have a single CSR updated.</font></p>

</font></td></tr></table>

<?
 $isLogin = 1;
 include($footer_file); 
?>
</body>

</html>