<?
/********************************************************************/
/* do NOT edit the .php file, because it is a COPY of the .HTM file */
/* so others can use front page as an editor.                       */
/********************************************************************/
?>

<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta http-equiv="Content-Language" content="en-us">
<title>Agents Products Page</title>
<?
  $cur_page="get_started";
  require("config.php");
  include($styles_file); 
?>
</head>

<body bgcolor="#FFFFFF" text="#000000" link="#999999" vlink="#990000" alink="#666666">

<?
include($header_file);  //note: don't specify "$page_title"
?>

<table border="0" cellpadding="0" cellspacing="0" width="100%"><tr><td valign="top" width="1%"><font face="Arial, Arial, Helvetica">


<p>&nbsp;</p>


<p>
&nbsp;</p>

</font></td><td valign="top" width="24"></td><td valign="top"><font face="Arial, Arial, Helvetica">
        <p> <font face="Arial" size="5">Instructions to get started</font></p>


<dl>

    <dt><font face="Arial">1) Fill out the agent application online
    <a href="agent_application.php">Agent Application</a></font></dt>



</dl>


<p><font face="Arial">2)&nbsp; Download the contract, sign it, then fax back to
801 972-6973&nbsp; <a href="ONLINE-CSR%20Agent%20Agreement.pdf">Download 
contract</a></font></p>
<p><font face="Arial">3) <a href="Qwest%20LOA.pdf">Download LOA</a></font></p>
<p><font face="Arial" size="5">The next step, Sell it, Here's how.<br>
</font><font face="Arial">(with the tools you are given the service will sell 
itself)</font></p>
<p><font face="Arial">Once you have registered, you will have your own 
ONLINE-CSR</font><font face="Arial"> web site with your information 
on it.&nbsp; (www.online-csr.com/agent_name)</font></p>
<p><font face="Arial">1) After you submit your online Agent Application you will 
be notified within 48 hours that your account has been set up.&nbsp; You will be 
given the URL to your custom ONLINE-CSR</font><font face="Arial"> 
web site.</font></p>
<p><font face="Arial">2) Have a customer visit your ONLINE-CSR</font><font face="Arial"> 
web site, and view the demonstration.&nbsp; You have the option of showing your 
pricing for the service or you can have your customer contact you directly for 
pricing.</font></p>
<p><font face="Arial">3) You can have your customer sign up for the service 
online by following the simple instructions or you can sign your customer up 
yourself. (A signed LOA must be submitted for each customer, your agency's name 
should be on the LOA)</font></p>
<p><font face="Arial">4) Within 5 business days your customer will be set up.&nbsp; 
Either you or you and the customer will be notified when the customers records 
can be viewed online.</font></p>
<p><font face="Arial">5) When the customers ONLINE-CSR 
service has been set up, be sure and have the customer edit or specify the 
location name, department and division for each CSR.&nbsp; You and the customer 
will be able to see which if any CSR's have problems when you see a red check.</font></p>
<p><font face="Arial">6) Follow up to see that any and all corrections have been 
made. (check online)</font></p>
<p><font face="Arial"><font size="5">OUR GUARANTEE</font><br>
We know that this is a valuable service for customers that have multiple CSR's.&nbsp; 
The larger the customer the more valuable the service. Therefore we will offer 
this guarantee. Any customer may cancel their ONLINE-CSR 
service in the first 10 days and they will not be billed.&nbsp; This guarantee 
is extended to all agents. If ONLINE-CSR 
feels that this guarantee is being abused by any agent the guarantee will be 
rescinded for that agent.<br>
&nbsp;</font></p>
<p><font face="Arial">We appreciate your feedback <a href="feedback.php">
FEEDBACK</a></font></p>

</font></td></tr></table>
<?
 $isLogin = 1;
 include($footer_file); 
?>

</font></td></tr></table></body>
</html>