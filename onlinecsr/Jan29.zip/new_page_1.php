<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Notes</title>
<meta name="GENERATOR" content="Microsoft FrontPage 5.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta name="Microsoft Theme" content="blank 000, default">
<meta name="Microsoft Border" content="tlb, default">
</head>

<body bgcolor="#FFFFFF" text="#000000" link="#999999" vlink="#990000" alink="#666666"><!--msnavigation--><table border="0" cellpadding="0" cellspacing="0" width="100%"><tr><td><!--mstheme--><font face="Arial, Arial, Helvetica">




<p align="center">
&nbsp;<img border="0" src="_borders/LOGO%2024.gif" width="307" height="53"><br>
<b><font size="2" color="#666666"><a href="../myweb/index.php">Home</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="index.php">Agents</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="get_started.php">Get Started</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="agent_application.php">Agent Application</a>&nbsp;&nbsp;&nbsp;
<a href="pricing.php">Pricing</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="ONLINE-CSR%20Agent%20Agreement.pdf">Contract</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="Qwest%20LOA.pdf">LOA</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="feedback.php">Feedback</a></font></b></p>

<!--mstheme--></font></td></tr><!--msnavigation--></table><!--msnavigation--><table border="0" cellpadding="0" cellspacing="0" width="100%"><tr><td valign="top" width="1%"><!--mstheme--><font face="Arial, Arial, Helvetica">


<p>&nbsp;</p>


<p>
&nbsp;</p>

<!--mstheme--></font></td><td valign="top" width="24"></td><!--msnavigation--><td valign="top"><!--mstheme--><font face="Arial, Arial, Helvetica">
<p>Things to add/change</p>
<p><b><font color="#800080" size="4">Phase I (12/31/02)</font></b><br>
A. Get program up and working, interacting with the database.<br>
B. Have the Demo fully functional.<br>
<font color="#FF0000">C. Have the pages cleaned up an looking nice.&nbsp; [Theme 
- Shades of Gray] he { Done by I-4}</font><br>
D. Include the &quot;Remind Date&quot; as a field on the AMC page<br>
&nbsp;&nbsp;&nbsp; (This field will be automatically checked each day @ 5:00 AM, 
when the field = Today send an email to the Qwest team containing all the fields 
in the record. If the &quot;Remind Date&quot; is not changed it will continue to send a 
remind email to the Qwest team.)<br>
E.&nbsp; Add to big buttons on the home page&nbsp; &quot;Log In&quot; &amp; &quot;View Demo&quot;<br>
<font color="#FF0000">F.&nbsp; Create Logo with LCD Font</font>
<font color="#FF0000">{ Done by I-4}<br>
G. Create 3 different style pages one for agents web pages, one for the agents 
information and one for Online CSR.&nbsp; ( 
The difference between agents web pages and online-csr will be the links to the &quot;services&quot; and &quot;agents&quot; 
and &quot;about us&quot;){ Done by I-4}a a <br>
</font><font color="#0000FF">H. Get Steve some data files .txt with the 
associated .tab<br>
I. Prepare contracts for Agents and Providers<br>
J. Prepare the &quot;Fees&quot; page of the site<br>
K.&nbsp; Prepare the contract and LOA for the customer to sign<br>
L. Create agent's customer entry page<br>
M. Create customer&nbsp; sign up page<br>
</font><font color="#008080">N.&nbsp; Write text for Q&amp;A, Privacy &amp; About us</font></p>
<p><b><font size="4">Phase II (1/15/03)</font></b><br>
A. Write the code that will Create a dynamic Web entry page for each Agent from 
the Agent file. (add a box that says &quot;Create Web Page&quot;)<br>
B. Customer File, Add a field to hold the LOA PDF file.&nbsp; Display the PDF 
file when clicked<br>
C. Customer File, Add 6 fields or 1 field with 6 options &quot;Update CSRs&quot; each box 
will have a date in it. This field will be automatically checked each day @ 5:00 
AM, when the field = Today send an email to the Online-CSR staff.&nbsp; Add a 
field (radio Button) ONLINE-CSR Bills Customer or Agent Bills Customer.<br>
D. Agents file - add fields email address where sign-ups are sent, contact name&amp; 
#, 3 options [&nbsp; Always bill customer directly, Always bill Agent, Always 
ask who to bill], Add rates [ per CSR and per hour], agents home page, agents 
logo, Question &quot;allow customer to sign up for service on-line?&quot;&nbsp; Add 
agent's &quot;name w/plural&quot;&nbsp; Add Agency who they use to place orders.</p>
<p><b><font size="4">Phase III (2/15/03)</font></b><br>
A. Backup Data to another computer on the LAN<br>
&nbsp;</p>

<!--mstheme--></font><!--msnavigation--></td></tr><!--msnavigation--></table><!--msnavigation--><table border="0" cellpadding="0" cellspacing="0" width="100%"><tr><td><!--mstheme--><font face="Arial, Arial, Helvetica">

<p>&nbsp;</p>


<p>
</p>


<h5>

Send mail to <a href="mailto:webmaster@online-csr.com">
webmaster@online-csr.com</a> with
questions or comments about this web site.<br>


Copyright � 2002 OnLine-CSR, Inc.<br>


</h5>

<!--mstheme--></font></td></tr><!--msnavigation--></table></body>

</html>