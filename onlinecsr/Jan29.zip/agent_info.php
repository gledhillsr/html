<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>agent info</title>
<meta name="GENERATOR" content="Microsoft FrontPage 5.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<style>
<!--
.jim         {  }
-->
</style>
<meta name="Microsoft Theme" content="blank 000, default">
<meta name="Microsoft Border" content="tlb, default">
</head>

<body bgcolor="#FFFFFF" text="#000000" link="#999999" vlink="#990000" alink="#666666"><!--msnavigation--><table border="0" cellpadding="0" cellspacing="0" width="100%"><tr><td><!--mstheme--><font face="Arial, Arial, Helvetica">




<p align="center">
&nbsp;<img border="0" src="_borders/LOGO%2024.gif" width="307" height="53"><br>
<b><font size="2" color="#666666"><a href="../myweb/index.php">Home</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="index.php">Agents</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="get_started.php">Get Started</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="agent_application.php">Agent Application</a>&nbsp;&nbsp;&nbsp;
<a href="pricing.php">Pricing</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="ONLINE-CSR%20Agent%20Agreement.pdf">Contract</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="Qwest%20LOA.pdf">LOA</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="feedback.php">Feedback</a></font></b></p>

<!--mstheme--></font></td></tr><!--msnavigation--></table><!--msnavigation--><table border="0" cellpadding="0" cellspacing="0" width="100%"><tr><td valign="top" width="1%"><!--mstheme--><font face="Arial, Arial, Helvetica">


<p>&nbsp;</p>


<p>
&nbsp;</p>

<!--mstheme--></font></td><td valign="top" width="24"></td><!--msnavigation--><td valign="top"><!--mstheme--><font face="Arial, Arial, Helvetica">

<!--mstheme--></font><table border="0" cellpadding="0" cellspacing="0" width="100%">
<tr><td><!--mstheme--><font face="Arial, Arial, Helvetica">
<font face="Arial, Arial, Helvetica">
<p align="center">
&nbsp;<img border="0" src="images/ONCSR%20LOGO.jpg" width="307" height="53"><br>
<b><font size="2" color="#666666"><a href="index.php">Home</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="agent_login.php">Agents</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="get_started.php">Get Started</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="agent_application.php">Agent Application</a>&nbsp;&nbsp;&nbsp;
<a href="ONLINE-CSR%20Agent%20Agreement.pdf">Contract</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="Qwest%20LOA.pdf">LOA</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="feedback.php">Feedback</a></font></b></p>

</font><!--mstheme--></font></td></tr>
</table><!--mstheme--><font face="Arial, Arial, Helvetica">

<p><b><font size="6"><font color="#666666">AGENTS</font> <font color="#999999">- 
Welcome</font></font></b></p>
<p><b><font size="6" color="#999999">Password Required<br>
&nbsp;</font></b></p>
<form method="POST" action="_derived/nortbots.htm" webbot-action="--WEBBOT-SELF--" onSubmit="location.href='_derived/nortbots.htm';return false;" WEBBOT-onSubmit>
  <!--webbot bot="SaveResults" U-File="_private/form_results.csv" S-Format="TEXT/CSV" S-Label-Fields="TRUE" startspan --><input TYPE="hidden" NAME="VTI-GROUP" VALUE="0"><!--webbot bot="SaveResults" i-checksum="43374" endspan --><p>
  <input type="text" name="T1" size="20"><br>
  <input type="submit" value="Submit" name="B1"><input type="reset" value="Reset" name="B2"></p>
</form>
<p><font color="#333333" size="4">If you do not have a password email us and we 
will get it to you<br>
agentmanager@online-csr.com</font></p>

<!--mstheme--></font><!--msnavigation--></td></tr><!--msnavigation--></table><!--msnavigation--><table border="0" cellpadding="0" cellspacing="0" width="100%"><tr><td><!--mstheme--><font face="Arial, Arial, Helvetica">

<p>&nbsp;</p>


<p>
</p>


<h5>

Send mail to <a href="mailto:webmaster@online-csr.com">
webmaster@online-csr.com</a> with
questions or comments about this web site.<br>


Copyright � 2002 OnLine-CSR, Inc.<br>


</h5>

<!--mstheme--></font></td></tr><!--msnavigation--></table></body>

</html>