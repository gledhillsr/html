<?
/********************************************************************/
/* do NOT edit the .php file, because it is a COPY of the .HTM file */
/* so others can use front page as an editor.                       */
/********************************************************************/
?>
<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>About_us</title>
<?
  $cur_page="about_us";
  require("config.php");
  include($styles_file); 
?>
</head>

<body bgcolor="#FFFFFF" text="#000000" link="#999999" vlink="#990000" alink="#666666">
<?
include($header_file);  //note: don't specify "$page_title"
?>

<table border="0" cellpadding="0" cellspacing="0" width="100%"><tr><td valign="top" width="1%"><font face="Arial, Arial, Helvetica">


<p>&nbsp;</p>


<p>
&nbsp;</p>

</font></td><td valign="top" width="24"></td><td valign="top"><font face="Arial, Arial, Helvetica">
<p><br>
<font size="6" color="#666666">About Us</font></p>

<p><b>ONLINE-CSR�</b>, Inc. is a service bureau.&nbsp; Our primary mission is to 
provide information to business, government and education which will allow them 
to more effectively manage their telecommunication services and costs.<font face="Arial">&nbsp; ONLINE-CSR is comprised of ex-telephone company 
    personnel who recognized that there was a world of difference between the 
    information large telephone companies provided their customers and what 
    their customers needed in order to effectively manage their telecom 
    services.</font> ONLINE-CSR is not an agent for the telephone company.&nbsp; 
We work for you.</p>

<p>
                <font size="3" face="Arial">Our service is for medium to very large 
                enterprises.&nbsp; Our clients are customers of the RBOC 
                (Regional Bell Operating Company).&nbsp; Currently the only RBOC we 
                provide service for is Qwest.&nbsp; The remaining RBOCs will be 
                brought on board during 2003. </font><font face="Arial">&nbsp;Our service is used by 
    Qwest employees, Qwest agents, telecommunication consultants, governments, 
    education and business.</font></p>

<p>
                <font face="Arial" size="3"><b>WHY YOU NEED US<br>
                </b>The RBOCs have a complicated way of billing their customers. They base their 
                billing on USOC codes.&nbsp; If a customer currently wants their 
                local telephone company (RBOC) to provide them with a CSR 
                (customer service record)&nbsp; they 
                will receive a page of codes and prices.&nbsp; A CSR can only be read by
                someone who 
                has been trained.&nbsp; For a trained individual it is still a 
                laborious task to read a long CSR.&nbsp; With ONLINE-CSR's 
                proprietary software we can read the CSR, summarize it, convert 
                it to English, have an expert review it and post the results on 
                our web site at a cost previously unobtainable.</font></p>
                <p>
                <b>ONLINE-CSR�</b><font face="Arial"> simplifies the moves'
                adds and changes process. Our service provides a system where you can
                input requests for service and view the progress on all
                orders.&nbsp;</font></p>
                <p>
                <font face="Arial">The database of information allows customers
                to organize their telecommunication services by division or 
                department or look at a single location.&nbsp; </font>ONLINE-CSR
                puts the customer in control of all telecommunication
                costs.&nbsp;</p>
<p><b>COST OF SERVICE</b><br>
                We charge a fee for our service.&nbsp; The fees are based on the 
                number of customer service records (CSR's) that we are asked to 
                manage.&nbsp; If you need additional help straightening out your 
                account or dealing with the telephone company we will do that 
                for an hourly fee.&nbsp; Our advantage is that we know the 
                telephone companies systems and we know how to work them.&nbsp;
Once your information has been entered into the database, your services can be
easily reviewed by experts, they can help you fix billing errors and recommend
new services that reduce costs.&nbsp;</p>
                <p>&nbsp;</p>
                <dl>
                  <dt><strong><font size="3">Telephone</font></strong><font size="3">
                  </font></dt>
                  <dd><font size="3">801-463-8300</font></dd>
                  <dt><strong><font size="3">Postal address</font></strong><font size="3">
                  </font></dt>
                  <dd><font size="3">2722 So West Temple, Ste B, Salt Lake City, UT 
                  84115</font></dd>
                  <dt><strong><font size="3">Electronic mail</font></strong><font size="3">
                  </font></dt>
                  <dd><font size="3">General Information:
                  <a href="mailto:info@online-csr.com?subject=We Request More Information">
                  info@online-csr.com</a><br>
                  Agent Information:
                  <a href="mailto:agentmgr@online-csr.com?subject=Request Agent Information">
                  agentmgr@online-csr.com</a><br>
&nbsp;</font></dd>
                </dl>
			
<p>&nbsp;</p>
</font></td></tr></table>

<?
 $isLogin = 1;
 include($footer_file); 
?>

</body>
</html>