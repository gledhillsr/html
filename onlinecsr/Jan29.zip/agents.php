<? include("topInclude.php"); ?>
<table border="0" cellpadding="0" cellspacing="0">
         	<tr>
         		<td class="title1">AGENTS - Work Smarter not Harder <br><br></td>
         	</tr>
	<tr>
         		<td class="title2">WELCOME to ONLINE-CSR<SUP><FONT SIZE="-1">TM</FONT></SUP></td>  
         	</tr>
	<tr>
         		<td class="main">Our service is for medium to very large enterprises.  
			Your clients must be customers of the RBOC (Regional Bell Operating Company).  
			Currently the only RBOC we provide service for is Qwest.  The remaining RBOCs will be 
			brought on board during 2003.
			<p>The RBOCs have a very old, archaic and complicated way of billing their customers. 
			They base their billing on USOC codes.  If a customer currently wants their RBOC to provide 
			them with a CSR (customer service record) then they will receive a page of codes.  A CSR 
			can only be read by one who has been trained.  For a trained individual it is still a laborious 
			task to read a long CSR.  With ONLINE-CSR<SUP><FONT SIZE="-1">TM</FONT></SUP>'s proprietary software we can read the CSR, summarize it, 
			convert it to English, have an expert review it and post the results on our web site at a cost 
			previously unobtainable.</td>
         	</tr>
	<tr>
		<td><img src="images/00-bit.gif" width="1" height="30"></td>
	</tr>
</table>
<? include("footer1.php"); ?>