<?
	setCookie("user_id");
	setCookie("customer_id","abc");
	setCookie("user_name","Demo User");
	setCookie("customer_name","ABC Company");
	setCookie("agency_name","Sample Agency");
	setCookie("agency_id","super");
	setCookie("isAdmin","1");
	setCookie("isDemo","1");
?>