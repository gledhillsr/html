<?
/********************************************************************/
/* do NOT edit the .php file, because it is a COPY of the .HTM file */
/* so others can use front page as an editor.                       */
/********************************************************************/

$cur_page="agents1";

?>
<html>
<head>
	<title>CSR</title>
	<link rel="STYLESHEET" type="text/css" href="includes/styles.css">
</head>

<body bgcolor="#000052" marginwidth="0" marginheight="0" topmargin="0" leftmargin="0">

<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td bgcolor="#1c1c1c"><a href="index.php">
        <img src="images/hdr_1.jpg" border="0" width="249" height="92"></a></td>
		<td width="100%" bgcolor="#000052" align="right" valign="top"><img src="images/00-bit.gif" width="1" height="25"><br>
			<table border="0" cellpadding="0" cellspacing="10">
            	<tr>
					<td><a class="nav1" href="index.php">Home</a></td>
            		<td><a class="nav1" href="agents1.php">Agents</a></td>
					<td><a class="nav1" href="get_started.php">Get Started</a></td>
					<td><a class="nav1" href="pricing.php">Pricing</a></td>
					<td><a class="nav1" href="agent_application.php?owner=<? echo $cur_page; ?>">Agent Application</a></td>
					<td><a class="nav1" href="ONLINE-CSR%20Agent%20Agreement.pdf">Contract</a></td>
					<td><a class="nav1" href="Qwest%20LOA.pdf">LOA</a></td>
					<td><a class="nav1" href="feedback.php?owner=<? echo $cur_page; ?>">Feedback</a></td>
					<td><img src="images/00-bit.gif" width="10" height="1"></td>
            	</tr>
            </table></td>
	</tr>
	<tr>
		<td bgcolor="#ffffff"><img src="images/00-bit.gif" width="1" height="1"></td>
		<td bgcolor="#ffffff"><img src="images/00-bit.gif" width="521" height="1"></td>
	</tr>
	<tr>
		<td bgcolor="#000052"><img src="images/hdr_2.jpg" width="249" height="30"></td>
		<td bgcolor="#000052">&nbsp;</td>
	</tr>
	<tr>
		<td bgcolor="#6a6a6a"><img src="images/00-bit.gif" width="1" height="10"></td>
		<td bgcolor="#777777"><img src="images/00-bit.gif" width="1" height="10"></td>
	</tr>
	<tr>
		<td bgcolor="#e3e3e3" valign="top">
<!-- nav table :: start -->
			<table border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td><img src="images/00-bit.gif" width="1" height="10"></td>
				</tr>
				<tr>
					<td><img src="images/00-bit.gif" width="35" height="1"><a class="nav2" href="index.php">Home</a></td>
	        	</tr>
				<tr>
					<td><img src="images/spacer_g.gif" width="243" height="15"></td>
				</tr>
				<tr>
					<td><img src="images/00-bit.gif" width="35" height="1"><a class="nav2" href="agents1.php">Agents</a></td>
	        	</tr>
				<tr>
					<td><img src="images/spacer_g.gif" width="243" height="15"></td>
				</tr>
				<tr>
	        		<td><img src="images/00-bit.gif" width="35" height="1"><a class="nav2" href="get_started.php">Get Started</a></td>
	        	</tr>
				<tr>
					<td><img src="images/spacer_g.gif" width="243" height="15"></td>
				</tr>
				<tr>
	        		<td><img src="images/00-bit.gif" width="35" height="1"><a class="nav2" href="pricing.php">Pricing</a></td>
	        	</tr>
				<tr>
					<td><img src="images/spacer_g.gif" width="243" height="15"></td>
				</tr>
				<tr>
	        		<td><img src="images/00-bit.gif" width="35" height="1"><a class="nav2" href="agent_application.php?owner=<? echo $cur_page; ?>">Agent Application</a></td>
	        	</tr>
				<tr>
					<td><img src="images/spacer_g.gif" width="243" height="15"></td>
				</tr>
				<tr>
	        		<td><img src="images/00-bit.gif" width="35" height="1"><a class="nav2" href="ONLINE-CSR%20Agent%20Agreement.pdf">Contract</a></td>
	        	</tr>
				<tr>
					<td><img src="images/spacer_g.gif" width="243" height="15"></td>
				</tr>
				<tr>
	        		<td><img src="images/00-bit.gif" width="35" height="1"><a class="nav2" href="Qwest%20LOA.pdf">LOA</a></td>
	        	</tr>
				<tr>
					<td><img src="images/spacer_g.gif" width="243" height="15"></td>
				</tr>
				<tr>
	        		<td><img src="images/00-bit.gif" width="35" height="1"><a class="nav2" href="feedback.php?owner=<? echo $cur_page; ?>">Feedback</a></td>
	        	</tr>
				<tr>
					<td><img src="images/spacer_g.gif" width="243" height="15"></td>
				</tr>
				<tr>
					<td><img src="images/00-bit.gif" width="1" height="10"></td>
				</tr>
	        </table></td>
<!-- nav table :: end -->
		<td bgcolor="#ffffff" valign="top"><table border="0" cellpadding="0" cellspacing="0">
         	<tr>
         		<td class="title1"><b>
                <font face="Arial" size="7" color="#666666">Agents Welcome to 
                ONLINE-CSR</font></b><br><br></td>
         	</tr>
	<tr>
         		<td class="title2"><b>
                <font color="#999999" face="Arial" size="6">Work Smarter not 
                Harder</font></b></td>  
         	</tr>
	<tr>
         		<td class="main"><font face="Arial">&nbsp;&nbsp; <br>
                <font size="3">Our service is for medium to very large 
                enterprises.&nbsp; Your clients must be customers of the RBOC 
                (Regional Bell Operating Company).&nbsp; Currently the only RBOC we 
                provide service for is Qwest.&nbsp; The remaining RBOCs will be 
                brought on board during 2003.</font></font><p>
                <font face="Arial" size="3">The RBOCs have a very old, archaic 
                and complicated way of billing their customers. They base their 
                billing on USOC codes.&nbsp; If a customer currently wants their RBOC 
                to provide them with a CSR (customer service record) then they 
                will receive a page of codes.&nbsp; A CSR can only be read by one who 
                has been trained.&nbsp; For a trained individual it is still a 
                laborious task to read a long CSR.&nbsp; With ONLINE-CSR's 
                proprietary software we can read the CSR, summarize it, convert 
                it to English, have an expert review it and post the results on 
                our web site at a cost previously unobtainable.</font></p>
                <p><font face="Arial" size="3"><b>OPPORTUNITY</b><br>
                Where the opportunity lies, is that every RBOC customer would 
                like to know exactly what they are being charged for and have 
                someone other than their RBOC check their CSR's for accuracy.&nbsp; 
                In the past this has been a time intensive and expensive 
                proposition.&nbsp; Our first customer was a government entity that 
                was being charged for services in a building that was demolished 
                years ago. We have found that the first person that walks 
                through the door and provides a client with a solution to a 
                problem they have had for years can win the business (almost) 
                automatically.&nbsp; Generally the fees earned for this service pale 
                in comparison to the commissions earned for placing new orders 
                with the RBOC.</font></p>
                <p><font face="Arial" size="3"><b>MADE for AGENTS</b><br>
                We have designed ONLINE-CSR</font><font face="Arial"><span style="FONT-SIZE: 12pt">
                </span><font size="3">for agents and consultants.&nbsp; The price for 
                the service is set by the agent.&nbsp; An agent will have a buy rate 
                depending on the size (number of CSRs) of their client.&nbsp; An 
                agent can mark up the service to maintain a 50% commission, 
                while a paid consultant may choose to offer the service at 
                cost.&nbsp; The agent has the choice to bill the client directly or 
                have ONLINE-CSR</font><span style="FONT-SIZE: 12pt"> </span>
                <font size="3">bill them.&nbsp; The &quot;standard service&quot; updates the 
                CSR information every six months.&nbsp; A client may opt to have 
                their records updated every three months which would increase 
                the cost for their service.&nbsp;&nbsp; </font></font></p>
                <p><font face="Arial" size="3"><b>BUILD and PROMOTE YOUR 
                BUSINESS<br>
                </b>ONLINE-CSR is a privately owned service bureau.&nbsp; We are not 
                an agent for the RBOC competing against you. ONLINE-CSR</font><font face="Arial" size="3"> 
                was designed to be licensed by agents and consultants.&nbsp; Each 
                agent will have their own privately labeled entry page to the 
                web site for their customers to view, listing your name as the 
                contact person.&nbsp; Each page of the web site will refer back to 
                the referring agent, all printouts will reference your business 
                and will link to your web site.&nbsp; Your agency is a licensed user 
                of the software. As far as your customer knows, it is your 
                service.&nbsp;&nbsp; If you are currently an agent and can place your own 
                orders for service with the LEC&nbsp; this service will dramatically 
                increase your orders and help your sub agents.&nbsp; If you need a 
                master agent to work thru we can provide you with a list of 
                larger more secure agencies. </font></p>
                <p><font face="Arial" size="3"><b>FREE ADVICE</b><br>
                This service is a &quot;no-brainer&quot; for large users, it will sell 
                itself.&nbsp; Start by approaching the largest customers you can get 
                to.&nbsp; You can sell it by sending a simple email. Keep in mind 
                that governments, education and national accounts are prime 
                candidates for this service.&nbsp; When someone subscribes for the 
                service you have your foot in the door and your name in front of 
                them for years to come as their &quot;service provider&quot;.&nbsp; Go make 
                some money.</font></p>
                <dl>
                  <dt><strong><font size="3">Telephone</font></strong><font size="3">
                  </font></dt>
                  <dd><font size="3">801-464-0100</font></dd>
                  <dt><strong><font size="3">Postal address</font></strong><font size="3">
                  </font></dt>
                  <dd><font size="3">2722 So West Temple, Salt Lake City, UT 
                  84115</font></dd>
                  <dt><strong><font size="3">Electronic mail</font></strong><font size="3">
                  </font></dt>
                  <dd><font size="3">General Information:
                  <a href="mailto:info@online-csr.com?subject=We Request More Information">
                  info@online-csr.com</a><br>
                  Agent Information:
                  <a href="mailto:agentmgr@online-csr.com?subject=Request Agent Information">
                  agentmgr@online-csr.com</a><br>
&nbsp;</font></dd>
                </dl>
			<p>&nbsp;</td>
         	</tr>
	<tr>
		<td><img src="images/00-bit.gif" width="1" height="30"></td>
	</tr>
</table>
		</td>
	</tr>
	<tr>
		<td>
		</td>
		<td valign="top" align="right"><table border="0" cellpadding="0" cellspacing="10">
            	<tr>	
					<td><a class="nav1" href="index.php">Home</a></td>
            		<td><a class="nav1" href="agents1.php">Agents</a></td>
					<td><a class="nav1" href="get_started.php">Get Started</a></td>
					<td><a class="nav1" href="pricing.php">Pricing</a></td>
					<td><a class="nav1" href="agent_application.php?owner=<? echo $cur_page; ?>">Agent Application</a></td>
					<td><a class="nav1" href="ONLINE-CSR%20Agent%20Agreement.pdf">Contract</a></td>
					<td><a class="nav1" href="Qwest%20LOA.pdf">LOA</a></td>
					<td><a class="nav1" href="feedBack.php?owner=<? echo $cur_page; ?>">Feedback</a></td>
					<td><img src="images/00-bit.gif" width="10" height="1"></td>
            	</tr>
            </table>
		</td>
	</tr>
</table>

</body>
</html>