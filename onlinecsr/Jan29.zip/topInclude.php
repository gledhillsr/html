<html>
<head>
	<title>CSR</title>
	<link rel="STYLESHEET" type="text/css" href="includes/styles.css">
</head>

<body bgcolor="#000052" marginwidth="0" marginheight="0" topmargin="0" leftmargin="0">

<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td bgcolor="#1c1c1c"><a href="index.php"><img src="images/hdr_1.jpg" width="249" height="92" border="0"></a></td>
		<td width="100%" bgcolor="#000052" align="right" valign="top"><img src="images/00-bit.gif" width="1" height="25"><br>
			<table border="0" cellpadding="0" cellspacing="10">
            	<tr>
					<td><a class="nav1" href="index.php">Home</a></td>
            		<td><a class="nav1" href="agents.php">Agents</a></td>
					<td><a class="nav1" href="getStarted.php">Get Started</a></td>
					<td><a class="nav1" href="agent_application.php?owner=<? echo $cur_page; ?>">Agent Application</a></td>
					<td><a class="nav1" href="contact.php">Contact</a></td>
					<td><a class="nav1" href="loa.php">LOA</a></td>
					<td><a class="nav1" href="feedBack.php">Feedback</a></td>
					<td><img src="images/00-bit.gif" width="10" height="1"></td>
            	</tr>
            </table></td>
	</tr>
	<tr>
		<td bgcolor="#ffffff"><img src="images/00-bit.gif" width="1" height="1"></td>
		<td bgcolor="#ffffff"><img src="images/00-bit.gif" width="521" height="1"></td>
	</tr>
	<tr>
		<td bgcolor="#000052"><img src="images/hdr_2.jpg" width="249" height="30"></td>
		<td bgcolor="#000052">&nbsp;</td>
	</tr>
	<tr>
		<td bgcolor="#6a6a6a"><img src="images/00-bit.gif" width="1" height="10"></td>
		<td bgcolor="#777777"><img src="images/00-bit.gif" width="1" height="10"></td>
	</tr>
	<tr>
		<td bgcolor="#e3e3e3" valign="top">
<!-- nav table :: start -->
			<table border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td><img src="images/00-bit.gif" width="1" height="10"></td>
				</tr>
				<tr>
					<td><img src="images/00-bit.gif" width="35" height="1"><a class="nav2" href="index.php">Home</a></td>
	        	</tr>
				<tr>
					<td><img src="images/spacer_g.gif" width="243" height="15"></td>
				</tr>
				<tr>
					<td><img src="images/00-bit.gif" width="35" height="1"><a class="nav2" href="agents.php">Agents</a></td>
	        	</tr>
				<tr>
					<td><img src="images/spacer_g.gif" width="243" height="15"></td>
				</tr>
				<tr>
	        		<td><img src="images/00-bit.gif" width="35" height="1"><a class="nav2" href="getStarted.php">Get Started</a></td>
	        	</tr>
				<tr>
					<td><img src="images/spacer_g.gif" width="243" height="15"></td>
				</tr>
				<tr>
	        		<td><img src="images/00-bit.gif" width="35" height="1"><a class="nav2" href="agent_application.php?owner=<? echo $cur_page; ?>">Agent Application</a></td>
	        	</tr>
				<tr>
					<td><img src="images/spacer_g.gif" width="243" height="15"></td>
				</tr>
				<tr>
	        		<td><img src="images/00-bit.gif" width="35" height="1"><a class="nav2" href="pricing.php">Pricing</a></td>
	        	</tr>
				<tr>
					<td><img src="images/spacer_g.gif" width="243" height="15"></td>
				</tr>
				<tr>
	        		<td><img src="images/00-bit.gif" width="35" height="1"><a class="nav2" href="contact.php">Contact</a></td>
	        	</tr>
				<tr>
					<td><img src="images/spacer_g.gif" width="243" height="15"></td>
				</tr>
				<tr>
	        		<td><img src="images/00-bit.gif" width="35" height="1"><a class="nav2" href="loa.php">LOA</a></td>
	        	</tr>
				<tr>
					<td><img src="images/spacer_g.gif" width="243" height="15"></td>
				</tr>
				<tr>
	        		<td><img src="images/00-bit.gif" width="35" height="1"><a class="nav2" href="feedBack.php">Feedback</a></td>
	        	</tr>
				<tr>
					<td><img src="images/spacer_g.gif" width="243" height="15"></td>
				</tr>
				<tr>
					<td><img src="images/00-bit.gif" width="1" height="10"></td>
				</tr>
	        </table></td>
<!-- nav table :: end -->
		<td bgcolor="#ffffff" valign="top">