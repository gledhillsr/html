<?
$config_file = "config.php";  // Full path and name of the config file
$amc_table    = "amc";      // MySQL table name
$cur_page="edit_amc";
$page_title = "CSR-ONLINE Adds, Moves and Changes Editor";  // Page title

require($config_file);


if ($edit_flag == "edit")
 $manager_name = "Editing Add, Move, Change Request";
else
 $manager_name = "Adding New Add, Move, Change Request";
$button_line = "";
if($isAdmin)
  $button_line .= "<a href=\"admin.php\">Admin</a>&nbsp;&nbsp;&nbsp;&nbsp;";
$button_line .= "<a href=\"inventory.php\">Line&nbsp;Inventory</a>&nbsp;&nbsp;&nbsp;&nbsp;" .
"<a href=\"amc.php\">Adds, Moves, &amp; Changes</a>&nbsp;&nbsp;&nbsp;&nbsp;" .
"<a href=\"archive.php\">Archive</a>&nbsp;&nbsp;&nbsp;&nbsp;" .
"<a href=\"help_amc_edit.htm\">Help</a>&nbsp;&nbsp;&nbsp;&nbsp;" .
"<a href=\"log_off.php\">Log Off</a>";

if ( (!$entry AND !$add AND !$edit_add) OR ($edit_cancel) )
 {
 header("Location: amc.php");	/* Redirect browser */ 
 exit;
 }

$extra_header_str = "<style>\n"
. " .main{font-size:14pt;color:teal;}\n"
. " .small{font-size:10px;font-family : Verdana;}\n"
. " .input{background-color: #eeeeee;font-family : Verdana;}\n"
. " BODY, TD {font-family : Verdana;font-size:10pt;}\n"
. "</style>\n";

//include($header_file); 
//include($box_header_file); 

if ($edit_update)
 {
 update_db("edit");
 exit;
 }

if ($edit_delete)
 {
 update_db("delete");
 exit;
 }

if ($edit_add)
 {
 update_db("add");
 exit;
 }

if ($add)
 {
 edit_db("add");
 exit;
 }

edit_db("edit");
exit;

/*********************/
/*      edit_db      */
/*********************/

function edit_db($edit_flag)
{
global $ReqTime, $entry, $amc_field, $mysql_host, $mysql_username, $mysql_password, $mysql_db, $amc_table;
global $phppwd_1, $SCRIPT_NAME, $user_name, $customer_id, $customer_name, $btn_field, $user_id;
global $edit_field4, $edit_field10, $user_table, $user_field, $edit_field12, $UsersNotified;

global $page_title,$agent, $header_file, $box_header_file, $agency_name;
global $styles_file, $extra_header_str, $body_bgcolor, $body_link_color, $body_vlink_color, $body_alink_color;
global $manager_name, $button_line, $isAdmin, $button_line, $email_from;
global $body_text_color, $body_link_color, $body_hover_color;

include($header_file); 
include($box_header_file); 

//MySQL query: connect and retrieve AMC count 
$connect_string = @mysql_connect($mysql_host, $mysql_username, $mysql_password) or die ("Could not connect to the database.");

if ($edit_flag == "edit")
 {
 $query_string = "SELECT *  FROM " . $amc_table . " WHERE " . $amc_field[2][1] . "=\"" . $entry  . "\" AND " . $amc_field[2][4] . "=\"" . $ReqTime . "\" LIMIT 1";

//echo $query_string; // Debug only

 $result = @mysql_db_query($mysql_db, $query_string) or die ("Invalid query (result)");
 $amc_row = @mysql_fetch_array($result);
 $UsersNotified = $amc_row[$amc_field[2][12]];
 @mysql_free_result($result);
 }

?>

<form method="POST" action="<? echo $SCRIPT_NAME . "?entry=" . urlencode($entry); ?>" name="edit_form">

<p>
<table align="center" bgcolor="#000000">
<tr>
 <td><table border="1" align="center" bgcolor="#C0C0C0" cellspacing="1" cellpadding="4">
 <tr>
  <td align="center"><? echo $amc_field[1][1]; ?></td>
  <td>
<?
  if ($edit_flag == "add" && $entry == "") {
     echo "<select size=\"1\" name=edit_field1 >";
//------ build a list of all BTN's for this customer ------------
     $query_string = "SELECT BTN  FROM btn WHERE " . $btn_field[2][11] . "=\"" . $customer_id . "\"";
//echo $query_string; // Debug only
     $result = @mysql_db_query($mysql_db, $query_string) or die ("Invalid query (result)");
//     $btn_row = @mysql_fetch_array($result);
     $cnt = 0;
     echo "<option Selected>New Service</option>\n";
     while ($btn_row = @mysql_fetch_array($result))
     {
        $phone = $btn_row[ $btn_field[2][1] ];
        echo "<option>" . $phone . "</option>\n";
     }
//-----------------
   } else {
//display current btn (edit/delete) mode
      echo "$entry";
   }
?>
  </select>
  </td>
 </tr>

 <tr>
  <td align="center"><? echo $amc_field[1][2]; ?></td>
  <td>
<?
  if ($edit_flag == "add") {
	  $foo = "Add";
  } else {
	  $foo = $amc_row[$amc_field[1][2]];
  }
?>
  <select size="1" name=<? echo "edit_field2" ?> >
    <option<? if($foo == Add) echo " Selected";?>>Add</option>
    <option<? if($foo == Move) echo " Selected";?>>Move</option>
    <option<? if($foo == Change) echo " Selected";?>>Change</option>
    <option<? if($foo == Request) echo " Selected";?>>Request</option>
    <option<? if($foo == Other) echo " Selected";?>>Other</option>
  </select>
  </td>
 </tr>

 <tr>
  <td align="center"><? echo $amc_field[1][3]; ?></td>
  <td><? echo "$user_name";  
  $edit_field3 = $user_id;
  ?>
  </td>
 </tr>

 <tr>
  <td align="center">Date Created</td>
  <td>
  	<? 
//----------------- 
//	$edit_field4 = time();
	if ($edit_flag == "add")
	   $edit_field4 = time();
	else
	   $edit_field4 = $amc_row[ $amc_field[2][4] ];
	echo date("l, F d, Y - h:i A",$edit_field4);
  	?>
	<input type="HIDDEN" name="edit_field4" VALUE="<?echo $edit_field4;?>">
  </td>
 </tr>

 <tr>
  <td align="center"><? echo $amc_field[1][5]; ?></td>					 
  <td><input type="text" size="60" maxlength="60" class="input" name="<? echo "edit_field5" . "\" value=\"" . htmlentities($amc_row[ $amc_field[2][5] ]); ?>">
 </tr>

 <tr>
  <td align="center"><? echo $amc_field[1][6]; ?></td>					 
  <td><input type="text" size="60" maxlength="60" class="input" name="<? echo "edit_field6" . "\" value=\"" . htmlentities($amc_row[ $amc_field[2][6] ]); ?>">
 </tr>

 <tr>
  <td align="center"><? echo $amc_field[2][7]; ?></td>
  <td><input type="text" size="20" maxlength="20" class="input" name="<? echo "edit_field7" . "\" value=\"" . htmlentities($amc_row[ $amc_field[2][7] ]); ?>">
  </td>
 </tr> 

 <tr>
  <td align="center">Remind Date</td>
  <td>
<?
	$sentDate = "";
	$noReminder = "";
	if ($edit_flag == "add")
		$delta = 3;
	else {
	    $delta = "";
		$remindDate = $amc_row[ $amc_field[2][8] ];
//		echo "--$remindDate--" . time() . "--<br>"; //debug
		if($remindDate > 0) {
			$delta = (($remindDate - time()) / (60 *60*24));
			if($delta > 0.0)
				$delta = (int)$delta + 1; //add for partial day
			else
				$delta = -1;
		} elseif($remindDate < 0) {
			$sentDate = date("m/d/y", -$remindDate);
		} else
			$noReminder = "Selected";
	}
?>

  <select size="1" name=<? echo "edit_field8" ?> >

<? if($sentDate != "")
	  echo "<option Selected>Sent on " . $sentDate . "</option>";
  echo "<option " . $noReminder . ">Send No Reminder</option>";
  if($delta < 0)
	echo "<option Selected>Reminder past due!</option>";
?>
    <option<? if($delta == 1) echo " Selected"; ?>>1 day from now</option>
    <option<? if($delta == 2) echo " Selected"; ?>>2 days from now</option>
    <option<? if($delta == 3) echo " Selected"; ?>>3 days from now</option>
    <option<? if($delta == 4) echo " Selected"; ?>>4 days from now</option>
    <option<? if($delta == 5) echo " Selected"; ?>>5 days from now</option>
    <option<? if($delta == 6) echo " Selected"; ?>>6 days from now</option>
    <option<? if($delta == 7) echo " Selected"; ?>>7 days from now</option>
    <option<? if($delta == 8) echo " Selected"; ?>>8 days from now</option>
    <option<? if($delta == 9) echo " Selected"; ?>>9 days from now</option>
    <option<? if($delta == 10) echo " Selected"; ?>>10 days from now</option>
    <option<? if($delta == 11) echo " Selected"; ?>>11 days from now</option>
    <option<? if($delta == 12) echo " Selected"; ?>>12 days from now</option>
    <option<? if($delta == 13) echo " Selected"; ?>>13 days from now</option>
    <option<? if($delta >= 14) echo " Selected"; ?>>14 days from now</option>
  </select>
  </td>
 </tr> 

 <tr>
  <td align="center"><? echo $amc_field[1][9]; ?></td>
  <td>
<?
  if($edit_flag == "add") {
    $foo = "Open";
  }
  else {
  $query_string = "SELECT Status FROM amc WHERE BTN=\"" . $entry  . "\" AND RequestDate=\"" . $edit_field4 . "\"";
//echo "$query_string<br>";
   $result = @mysql_db_query($mysql_db, $query_string) or die ("Invalid query (result)");
   $amc_row = @mysql_fetch_array($result);
   $foo = $amc_row[0];
  }
//echo "old status=($foo)<br>";
?>
  <select size="1" name=edit_field9>
    <option <? if($foo=="Open") echo "Selected"; ?>>Open</option>
    <option <? if($foo=="In Progress") echo "Selected"; ?>>In Progress</option>
    <option <? if($foo=="Closed") echo "Selected"; ?>>Closed</option>
  </select>
  </td>
 </tr> 

 <tr>
  <td align="center">Last Modified</td>
  <td>
  	<? 
	if ($edit_flag == "add")
	   $edit_field4 = time();
	else
	   $edit_field4 = $amc_row[ $amc_field[2][10] ];
	echo date("l, F d, Y - h:i A",$edit_field4);
	?>
  </td>
 </tr> 
 <tr>
  <td align="center">Request mailed to: </td>
  <td>
<?
 $cnt = 0;
 $query_string = "SELECT " . $user_field[2][4] . 
 	" FROM user  WHERE " . $user_field[2][3] . "=\"" . $customer_id  . "\" AND " .
	$user_field[2][7] . "=\"1\"";
//echo $query_string;
 $result = @mysql_db_query($mysql_db, $query_string) or die ("Invalid query (result)");
 while ($user_row = @mysql_fetch_array($result))
 {
	if($cnt == 0) echo "Notify: ";
	else          echo ", ";
	$cnt += 1;
    echo $user_row[ 0 ];
	echo "  ";
 }
?>
  <br>
  <table>
  <tr> <td valign="middle">AND:&nbsp;</td>
  <td>
  <select multiple=1 size="3" name=<? echo "edit_field12[]" ?> >
<?
// $query_string = "SELECT " . $user_field[2][1] . " AND " . $user_field[2][4] . 
// $query_string = "SELECT " . $user_field[2][4] . 
 $query_string = "SELECT * " . 
 	" FROM user  WHERE " . $user_field[2][3] . "=\"" . $customer_id  . "\" AND " .
	$user_field[2][7] . "=\"0\"";
//echo $query_string . "<br>";	//debug
 $result = @mysql_db_query($mysql_db, $query_string) or die ("Invalid query (result)");
 while ($user_row = @mysql_fetch_array($result))
 {
// echo "(".$user_row["LoginName"] . ") (" . $user_row["UserName"] . ")";
//  test if $user_row[0] exists in $UsersNotified.  If so, pre-select name
	$pos = strpos($UsersNotified, $user_row[$user_field[2][1]]);
	if ($pos === false) { // note: three equal signs
	    $sel = ""; // not found...
	} else {
		$sel = " Selected"; //found
	}

    echo "<option" . $sel . ">" . $user_row[$user_field[2][4]] . "</option>\n";
 }
?>
  </select>
  </td><td valign="middle">
  &nbsp;&nbsp;&nbsp;Use &lt;Ctrl&gt; Click to Select Multiple
  <td></tr>
</table>
  </td>
 </tr> 

 <tr>
  <td align="center" class="small">&nbsp</td><td align="center">
<?

if ($edit_flag == "edit")
 {
//  $foo = "" + $ReqTime; 
//echo "---$ReqTime---";
 ?> <input name="edit_update" type="submit" value="Update Request"> 
    <input name="edit_delete" type="submit" value="Delete Request"> 
	<input type="HIDDEN" name="ReqTime" VALUE="<?echo $ReqTime;?>">
 <?
 }
else 
 {
 ?> <input name="edit_add" type="submit" value="Add Request"><?
 }

?> <input name="edit_cancel" type="submit" value="Cancel">
  </td>
 </tr>	
</table></td>
</tr></table>
<p>
</form>
</body>
<? /* force page NOT to be cached */ ?>
<HEAD>
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Expires" CONTENT="-1">
</HEAD>
</html>
<?

//if ($edit_flag == "edit")
// {
 @mysql_close($connect_string);
 @mysql_free_result($result);
// }

}

/*********************/
/*    update_db      */
/*********************/

function update_db($update_flag)
{
global $ReqTime, $amc_field, $entry, $mysql_host, $mysql_username, $mysql_password, $mysql_db, $amc_table;
global $index_url, $SCRIPT_NAME, $edit_password, $form_password;
global $edit_field1, $edit_field2, $edit_field4, $edit_field5, $edit_field6;
global $edit_field7, $edit_field8, $edit_field9, $edit_field10, $user_name;
global $customer_id, $customer_name, $btn_field, $user_id, $edit_field12;

global $page_title,$agent, $header_file, $box_header_file, $agency_name;
global $styles_file, $extra_header_str, $body_bgcolor, $body_link_color, $body_vlink_color, $body_alink_color;
global $manager_name, $button_line, $isAdmin, $button_line, $email_from;
global $body_text_color, $body_link_color, $body_hover_color;


$edit_field3 =  $user_id;
$edit_field11=  $customer_id;

  $connect_string = @mysql_connect($mysql_host, $mysql_username, $mysql_password) or die ("Could not connect to the database.");
    //time or request
	$mod_time = time();
	//calculate reminder time
	if($edit_field8 == "Send No Reminder") 
		$edit_field8 = 0; //magic flag for NO reminder
	else {
		$days = (int)substr($edit_field8,0,2);
		$arr = getdate();
		$strDate = $arr['month'] . " " . $arr['mday'] . " " . $arr['year'];
		$due_time = strtotime ($strDate) + ($days * 60 * 60 * 24); //DUE AT 12AM
//echo "($strDate)<br>($mod_time)<br>(" . strtotime ($strDate) . ")<br>";
		
		if($days >= 1)
			$edit_field8 = $due_time;	//increment by n days from midnight this morning
		else
			$edit_field8 = -1;	//can not happen on 'add'
	}
	//get list of people to send notifications to
//echo "-------------------------<br>"; zzz
 $query_string = "SELECT LoginName, Email, NotifyAboutChanges, UserName" .
 	" FROM user  WHERE CustomerID=\"" . $customer_id  ."\"";
// 	. " AND " . "NotifyAboutChanges=\"1\"";
//echo $query_string . "<br>";
 $result = @mysql_db_query($mysql_db, $query_string) or die ("Invalid query (result)");
 $UsersNotified = "";
 $email_to = "";
 $cnt = 0;
 while ($user_row = @mysql_fetch_array($result))
 {
    $foo = $user_row["UserName"];
    $found = 0;
	if($edit_field12) {
      foreach ($edit_field12 as $name) {
        if($name == $user_row["UserName"]) {
	      $found = 1;
	      break;
  	    }
	  }
    }

	if($user_row["NotifyAboutChanges"] == "1" || $found == 1) 
	{
	  if($cnt > 0) {
	  	$UsersNotified .= " ";
	  	$email_to .= ", ";
	  }
	  $cnt += 1;
      $UsersNotified .=  $user_row["LoginName"];
      $email_to .=  $user_row["Email"];
	} else {
	  //check for matchup in edit_field12 here
//echo "dont send to: " . $user_row["LoginName"] . "<br>";
	}
 }
   $message= "=============Add, Move, or Change Request :===========\n\n";

  if ($update_flag == "edit")
   {
   $message .= "RECORD MODIFIED by: $user_name, on " . date("D F j, Y, g:i a") . "\n\n";
   modify_status($entry,"delete", "old");
   modify_status($entry,"add", "$edit_field9");
   $edit_field1 = $entry;
   $query_string = "UPDATE " . $amc_table . " SET " . 
   		$amc_field[2][2] . "=\"" . $edit_field2 . "\", " . 
   		$amc_field[2][3] . "=\"" . $user_id . "\", " . 
   		$amc_field[2][5] . "=\"" . $edit_field5 . "\", " . 
   		$amc_field[2][6] . "=\"" . $edit_field6 . "\", " . 
   		$amc_field[2][7] . "=\"" . $edit_field7 . "\", ";
	if($edit_field8 != -1) //only change date if valid
		$query_string .= $amc_field[2][8] . "=\"" . $edit_field8 . "\", ";
	$query_string .= $amc_field[2][9] . "=\"" . $edit_field9 . "\", " . 
   		$amc_field[2][10] . "=\"" . $mod_time . "\", " . 
   		$amc_field[2][11] . "=\"" . $edit_field11 . "\", " .
   		$amc_field[2][12] . "=\"" . $UsersNotified . 
   		"\" WHERE " . $amc_field[2][1] . "=\"" . stripslashes($entry) . "\" AND " .
		$amc_field[2][4] . "=\"" . $edit_field4 ."\" LIMIT 1";

   }
  elseif ($update_flag == "delete")
   {
   $edit_field1 = $entry;
   $message .= "RECORD DELETED by: $user_name, on " . date("D F j, Y, g:i a") . "\n\n";
	modify_status($entry,"delete", $edit_field9);

   $query_string = "DELETE FROM " . $amc_table . " WHERE " . 
   	$amc_field[2][1] . "=\"" . stripslashes($entry) . "\" AND " .
   	$amc_field[2][4] . "=\"" . $ReqTime . 
   	"\" LIMIT 1";
//echo  "<br>$query_string"; //debug only
   }
  else //add
   {
   $message .= "NEW RECORD ADDED by: $user_name, on " . date("D F j, Y, g:i a") . "\n\n";
    if($entry != "")
	   $edit_field1 = $entry;
	   	
	modify_status($edit_field1,"new", $edit_field9);

//on add, insert current time
	$edit_field4 = $mod_time;
	$edit_field10 = $mod_time;
	$edit_field3 = $user_id;

   $query_string = "INSERT INTO " . $amc_table . " (" . 
   		$amc_field[2][1]  . ", " . $amc_field[2][2]  . ", " . $amc_field[2][3] . ", " . 
   		$amc_field[2][4]  . ", " . $amc_field[2][5]  . ", " . $amc_field[2][6] . ", " . 
   		$amc_field[2][7]  . ", " . $amc_field[2][8]  . ", " . $amc_field[2][9] . ", " . 
   		$amc_field[2][10] . ", " . $amc_field[2][11] . ", " . $amc_field[2][12] .") VALUES (\"" . 
   		$edit_field1  . "\", \"" . $edit_field2  . "\", \"" . $edit_field3 . "\", \"" . 
   		$edit_field4  . "\", \"" . $edit_field5  . "\", \"" . $edit_field6 . "\", \"" . 
   		$edit_field7  . "\", \"" . $edit_field8  . "\", \"" . $edit_field9 . "\", \"" . 
   		$edit_field10 . "\", \"" . $edit_field11 . "\", \"" . $UsersNotified . "\")";
   }

//echo "<p>--- debugging stuff ---<br>";	//debug only
//echo "$query_string<br>"; 				//Debug only
//echo "--- end debugging stuff ---</p>";	//Debug only
   $message .= "BTN:            $edit_field1\n"
		. "Service:      $edit_field2\n"
		. "Initial Requested: $edit_field3\n"
		. "Instructions:  $edit_field5\n"
		. "Response:   $edit_field6\n"
		. "Order #:    $edit_field7\n"
		. "Status:     $edit_field9\n"
		. "Customer:     $customer_name\n";

   if($user_id) {
/****************/
//	 mail($email_to, $title, "$message", $email_from);
$frm = "edit_amc";
include("mail.php");

/****************/
      if($query_string)
		$result = mysql_db_query($mysql_db, $query_string) or die ("Invalid query (result)");
   }
include($header_file); 
include($box_header_file); 

?>

<html>
<head></head>
<body bgcolor="#FFFFFF" link="#000000" vlink="#000000" alink="red">
<p><br>
<center>

<table border="1" bgcolor="#F0F0F0" width="99%" align="center" cellspacing="2" cellpadding="8">
<tr><td align="center">
<br><b>
<?


   if(!$user_id) {
      echo "<h3>Database can not be modified in Demo mode!</h3><br>";
   }
  elseif ($update_flag == "edit")
   {
   echo "The Request has been updated!";
   }
  elseif ($update_flag == "delete")
   {
   echo "The Request has been deleted!";
   }
  else
   {
   echo "The Request has been added!";
   }

?>
</b>
<form method="POST" action="">
  <p>
  <input type="button" value="Return to Add, Move &amp; Change List" name="B3" onClick=window.location="amc.php">
  <input type="button" value="Add New Request" name="B1" onClick=window.location="<? echo $SCRIPT_NAME . "?add=1"; ?>">
  </p>
</form>

</td>
</table>
</center>

<br>
</body>
<? /* force page NOT to be cached */ ?>
<HEAD>
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Expires" CONTENT="-1">
</HEAD>
</html>

<?
  @mysql_close($connect_string);
  @mysql_free_result($result);

}

/*********************/
/*    modify_status  */
/*********************/
function modify_status($entry, $what, $status)
{
global $edit_field1, $edit_field4, $mysql_db, $user_id;

if(!$user_id) //don't modify in demo mode
  return;


if($entry == "New Service") //no BTN record
  return;

if($status == "old") {
//get original status
//echo "requested date=$edit_field4<br>";
  $query_string = "SELECT Status FROM amc WHERE BTN=\"" . $entry  . "\" AND RequestDate=\"" . $edit_field4 . "\"";
//echo "$query_string<br>";
   $result = @mysql_db_query($mysql_db, $query_string) or die ("Invalid query (result)");
   $amc_row = @mysql_fetch_array($result);
   $status = $amc_row[0];
//echo "old status=($status)<br>";
}


//echo "($entry) ($what) ($status)<br>";
//get original AMC
   $query_string = "SELECT AMC  FROM btn WHERE BTN=\"" . $entry  . "\"";
//echo "$query_string<br>"; // Debug only
   $result = @mysql_db_query($mysql_db, $query_string) or die ("Invalid query (result)");
   $amc_row = @mysql_fetch_array($result);
   $foo = $amc_row[0];
//echo "[$foo]<br>";
//convert to number
   $hi = (int) substr($foo,0,3);
   $med= (int) substr($foo,3,3);
   $lo = (int) substr($foo,6,3);
//echo "($hi) ($med) ($lo)  what=$what, status=$status<br>";
//alter correct number	
	if($what == "delete") {
		if ($status == "Open")
		  $hi -= 1;
		elseif ($status == "In Progress")
		  $med -= 1;
		elseif ($status == "Closed")
		  $lo -= 1;
	} else {
		if ($status == "Open")
		  $hi += 1;
		elseif ($status == "In Progress")
		  $med += 1;
		elseif ($status == "Closed")
		  $lo += 1;
	}
//echo "($hi) ($med) ($lo)<br>";
//convert back to string
	if($hi <= 0 || $hi > 999)    { $cnt = "000"; }
	elseif($hi <= 9)             { $cnt = "00" . $hi;}
	elseif($hi <= 99)            { $cnt = "0" . $hi;}
	elseif($hi <= 999)           { $cnt = "" . $hi;}

	if($med <= 0 || $med > 999)  { $cnt .= "000"; }
	elseif($med <= 9)            { $cnt .= "00" . $med;}
	elseif($med <= 99)           { $cnt .= "0" . $med;}
	elseif($med <= 999)          { $cnt .= "" . $med;}

	if($lo <= 0 || $lo > 999)    { $cnt .=  "000";}
	elseif($lo <= 9)             { $cnt .= "00" . $lo;}
	elseif($lo <= 99)            { $cnt .= "0" . $lo;}
	elseif($lo <= 999)           { $cnt .= "" . $lo;}

    $cnt .= "000";  //no archive count yet
//echo "[$cnt]<br>";	//debug

$query_string = "UPDATE btn SET AMC=\"" . $cnt . "\" WHERE BTN=\"" . $entry . "\"";
//echo "$query_string<br>"; //debug
	$result = mysql_db_query($mysql_db, $query_string) or die ("Invalid query (result)");
  @mysql_free_result($result);
}
?>