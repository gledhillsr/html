<?
/********************************************************************/
/* do NOT edit the .php file, because it is a COPY of the .HTM file */
/* so others can use front page as an editor.                       */
/********************************************************************/
?>
<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Privacy</title>
<?
  $cur_page="privacy";
  require("config.php");
  include($styles_file); 
?>
</head>

<body bgcolor="#FFFFFF" text="#000000" link="#999999" vlink="#990000" alink="#666666">
<?
include($header_file);  //note: don't specify "$page_title"
?>

<table border="0" cellpadding="0" cellspacing="0" width="100%"><tr><td valign="top" width="1%"><font face="Arial, Arial, Helvetica">


<p>&nbsp;</p>


<p>
&nbsp;</p>

</font></td><td valign="top" width="24"></td><td valign="top"><font face="Arial, Arial, Helvetica">
<p>&nbsp;</p>

<blockquote>
  <blockquote>
    <b>
    <p><font face="Arial" size="3">Privacy Commitment</font></b><font SIZE="2"><br>
    We are committed to providing you with telecom data that meets your needs.
    That commitment includes protecting private information we obtain about your
    company and your agent/vendor relationships. We have strict safeguards in
    place to protect this information.&nbsp;
    <font face="Arial">
    Please take a moment to read this Privacy Notice for some important
    information about your rights.</font></p>
    </font><b>
    <p><font face="Arial" size="3">Confidentiality and Security</font></b><font SIZE="2"><font face="Arial"><br>
    We restrict access to agent, vendor, and client information to those
    employees who need to have that information to provide services to you. The
    customer is always in charge of who has access to the database. We maintain
    up-to-date physical safeguards (like secure areas in buildings), electronic
    safeguards (like firewall), and procedural safeguards (like client
    authentication procedures to prevent information theft). We train our
    employees on their roles in protecting this private information, and conduct
    regular internal audits to support our commitment. They must keep the
    information we share with them safe and secure, and we do not allow them to
    use or share the information for any purpose other than the job they are
    hired to do.</font></p>
    </font><b>
    <p><font face="Arial" size="3">Information We May Collect</font></b><font SIZE="2"><font face="Arial"><br>
    When you become a client, we will collect information about your Telecom
    services, including information you give us. In order to access information
    from Qwest, the customer must sign a Letter of Agency. A copy is
    available for download.</font></p>
    </font><b>
    <p><font face="Arial" size="3">Information We May Share</font></b><font face="Arial"><font SIZE="1"><i><br>
    </i></font><font SIZE="2">We will share with every pre-qualified Agent or
    vendor the information we collect if they are approved by the Customer to
    have access to the information&nbsp;</font></font><font SIZE="2">
    <font face="Arial">
    This will provide our clients and their vendors with the same information
    insuring data continuity.</font></p>
    </font><b>
    <p><font face="Arial" size="3">Information We Will Not Share</font></b><font face="Arial" size="3"><br>
    </font><font face="Arial" SIZE="2">
    We will not under any circumstances share information about clients,
    customers, agents, or vendors with any outside source for the intention of
    marketing, surveying, gathering statistics, etc.
    ONLINE-CSR will not sell, distribute, or relay any information to any source
    outside the company itself for any reason.&nbsp;</font><font SIZE="2">
    <font face="Arial">
    All information will be held in the strictest confidence as it pertains to
    the services we provide.</font></p>
    </blockquote>
  </blockquote>
</font>

<p>&nbsp;</p>

</font></td></tr></table><table border="0" cellpadding="0" cellspacing="0" width="100%"><tr><td><font face="Arial, Arial, Helvetica">

<p>&nbsp;</p>




</font></td></tr></table>

<?
 $isLogin = 1;
 include($footer_file); 
?>

</body>
</html>