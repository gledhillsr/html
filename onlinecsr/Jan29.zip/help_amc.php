<!-- saved from url=(0022)http://internet.e-mail -->
<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 5.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>HELP SCREEN</title>
</head>

<body>

<p>&nbsp;</p>
<p align="center"><b><font face="Arial" color="#FF0000">HELP SCREEN (Adds, Moves 
&amp; Changes)</font></b><br>
<img border="0" src="images/help_amc.jpg" width="774" height="271"></p>
<p align="left"><font face="Arial"><b><font color="#FF0000">1) </font></b>
<font color="#FF0000"><b>New Request</b></font> This button adds new adds or 
change orders to the system.<br>
<font color="#FF0000"><b>2) Admin</b></font> This takes you to the administrator 
page. Admin privileges are required. <br>
<b><font color="#FF0000">3) Line Inventory</font></b> This takes you back to the 
Line Inventory Manager.<br>
<b><font color="#FF0000">4) Archive</font></b> This database keeps a record of 
all your previous change orders.<br>
<b><font color="#FF0000">5) Edit</font></b> This button takes you to the edit 
page where you an change existing orders,<br>
<b><font color="#FF0000">6) BTN</font></b> This is the Billing Telephone Number 
on you account. You can sort by BTN but you can not modify this field.<br>
<font color="#FF0000">
<b>7) Service </b></font>Describes what type of change is being made. Add, Move, 
Change, Fix, Inquire or Other<br>
<b><font color="#FF0000">8) Requested By</font></b> The name of the individual 
who created this request.<br>
<b><font color="#FF0000">9) Date Created</font></b> The date this request was 
created.<br>
<b><font color="#FF0000">10) Instructions</font></b> Instructions as to what 
needs to be changed or ordered.<br>
<font color="#FF0000"><b>11) Sent to </b></font>&nbsp;Who was this request sent 
to.<br>
<b><font color="#FF0000">12) Response</font></b> When the person who received 
this request places their response here.<br>
<b><font color="#FF0000">13) Order #</font></b> If an order or tracking number 
is generated then it is placed here for reference.<br>
<b><font color="#FF0000">14) Remind Date</font></b>&nbsp; The remind me date 
will remind the person who is placing the order that it is not complete. This 
keeps orders and changes from falling in the cracks. <br>
<font color="#FF0000"><b>15) Status</b></font> This field shows the current 
status of each order. Open, In Progress or Completed. A corresponding dot red, 
yellow or green respectively will be placed on the line inventory manager on the 
respective BTN.<br>
<b><font color="#FF0000">16) Last Modified</font></b> This shows the date when 
this request was last modified.<br>
</font>
<br>
</p>
<FORM method="POST" action="<? echo $SCRIPT_NAME ?>" name="demo">
<p align="center">
	<input type="button" value="Return to Adds Moves Changes Manager" name="B2" onClick=window.location="amc.php" >
</p>
</FORM>

</body>

</html>