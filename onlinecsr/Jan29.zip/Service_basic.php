<?
/********************************************************************/
/* do NOT edit the .php file, because it is a COPY of the .HTM file */
/* so others can use front page as an editor.                       */
/********************************************************************/
?>

<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta http-equiv="Content-Language" content="en-us">

<title>OnLine-CSR Service 1</title>
<?
  $cur_page="Service_basic";
  require("config.php");
  include($styles_file); 
?>
</head>

<body bgcolor="#FFFFFF" text="#000000" link="#999999" vlink="#990000" alink="#666666"  >
<?
include($header_file);  //note: don't specify "$page_title"
?>

<table border="0" cellpadding="0" cellspacing="0" width="100%"><tr><td valign="top" width="1%"><font face="Arial, Arial, Helvetica">


<p>&nbsp;</p>


<p>
&nbsp;</p>

</font></td><td valign="top" width="24"></td><td valign="top"><font face="Arial, Arial, Helvetica"><p>&nbsp;</p>

<p>&nbsp;</p>

<p>ONLINE-CSR provides Business, Government and Education Customers with
the information they need to control Telecommunication costs, and simplifies the
ordering process for new service and existing services.</p>

<font SIZE="4">
<p>View a simplified, summarized version of your telephone company records.</p>
</font><b>
<p>Set up Fee $200.00</p>
<p>BASIC SERVICE</b> This is the online service that gives you a view of what
you are being billed for by the telephone company and allows you to track
orders, adds, moves, changes and inquiries. The price is determined by the
number of customer service records (CSR's) you have.&nbsp;<br>
Pricing is as follows:&nbsp;</p>
<p>Updated twice annually<br>
1-24 records $30.00 per record per year<br>
25-199 records $24.00 per record per year<br>
199-399 records $20.00 per record per year<br>
400+ records $16.00 per record per year</p>
<b>
<p>LABOR</b> Labor is optional. Many times your account team will make all the
changes on your account. However, you may need changes made on your accounts,
and they are not revenue generating changes,. Who can you rely on to do the
work.&nbsp; Disconnects are a prime example, when you place an order for a
disconnect it is necessary to follow up and make sure the service actually gets
disconnected. You may choose to have a paid Account Consultant make changes on
your account. We use only senior Account Consultants (AC�s) with over 20 years
RBOC experience.&nbsp;</p>
<p>Labor is charged in quarter hour increments at the rate of $80.00 per hour.</p>
<b>
<p>EXTRA CSR UPDATES</b> After a change has been made on a CSR it is highly
recommended that another CSR be pulled to replace the outdated record.<br>
The price for extra CSR updates are $20.00.</p>

<p>&nbsp;</p>

</font></td></tr></table>
<?
 $isLogin = 1;
 include($footer_file); 
?>
</body>
</html>