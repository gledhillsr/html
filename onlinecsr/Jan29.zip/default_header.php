<p align="center">
&nbsp;<img border="0" src="images/ONCSR%20LOGO.jpg" width="307" height="53"><br>
</p>

<p  align="center"><b><font size="2" color="#666666">
<?
if ($isForm == "") {
  echo "<a href=\"index.php\">Home</a>&nbsp;&nbsp;&nbsp;\n";
  echo "<a href=\"login.php\">Log In</a>&nbsp;&nbsp;\n";
  echo "<a href=\"demo.php\">View Demo</a>&nbsp;&nbsp;\n";
  echo "<a href=\"services1.php\">Services</a>&nbsp;&nbsp;\n";
  echo "<a href=\"Order_service.php?owner=" . $cur_page . "\">Order Service</a>&nbsp;&nbsp;&nbsp;\n";
  echo "<a href=\"about_us.php\">About Us</a>&nbsp;&nbsp;&nbsp;\n";
  echo "<a href=\"privacy.php\">Privacy</a> &nbsp;&nbsp;\n";
  echo "<a href=\"agent_login.php\">Agents</a>\n";
}
?>
<br></font></b>
</p>
