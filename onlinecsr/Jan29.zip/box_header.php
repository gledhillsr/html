<?	/* This is the Header. You can use HTML and PHP code here. 
           It will be included at the top of the page.             */ ?>
<table border="0" cellpadding="0" cellspacing="0" width="100%"><tr><td align="center" >
<font face="Arial, Arial, Helvetica">
<div style="width: 743px; height: 44px; border-style: solid; border-width: 1px; padding-left: 4px; padding-right: 4px; padding-top: 0px; padding-bottom: 4px;">
  <p align="center">&nbsp; <font face="Verdana"><b><font size="5"><? echo "$customer_name"; ?></font><br>
  <? echo "$manager_name" ?><br>
  </b><font size="2">Provided by <b><? echo "$agency_name"; ?></b></font></font></div>
</td></tr>
<tr><td align="center" >
<p><font face="Arial"><b>
<font size="4">
<?
	echo "$button_line";
?>
</font></b></font></p>
</td></tr>
</table>