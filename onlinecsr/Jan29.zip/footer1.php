		</td>
	</tr>
	<tr>
		<td><div style="padding: 10px 10px 10px 10px"><a href="http://www.i4.net"><img src="images/i4logo.gif" width="141" height="50" border="0"></a></div></td>
		<td valign="top" align="right"><table border="0" cellpadding="0" cellspacing="10">
            	<tr>	
					<td><a class="nav1" href="index.phpl">Home</a></td>
            		<td><a class="nav1" href="agents.php">Agents</a></td>
					<td><a class="nav1" href="getStarted.php">Get Started</a></td>
					<td><a class="nav1" href="agent_application.php?owner=<? echo $cur_page; ?>">Agent Application</a></td>
					<td><a class="nav1" href="contact.php">Contact</a></td>
					<td><a class="nav1" href="loa.php">LOA</a></td>
					<td><a class="nav1" href="feedBack.php">Feedback</a></td>
					<td><img src="images/00-bit.gif" width="10" height="1"></td>
            	</tr>
            </table>
		</td>
	</tr>
</table>

</body>
</html>