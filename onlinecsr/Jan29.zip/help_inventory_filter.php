<!-- saved from url=(0022)http://internet.e-mail -->
<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 5.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>HELP SCREEN</title>
</head>

<body>
<h2>Line Inventory Filter Edit Help.  Under Construction</h2>
<br>
<br>
<FORM method="POST" action="<? echo $SCRIPT_NAME ?>" name="demo">
<p align="center">
	<input type="button" value="Return to Inventory Filter" name="B2" onClick=history.back() >
</p>
</FORM>

</body>

</html>
