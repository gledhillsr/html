<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Terms &amp; Conditions</title>
</head>

<body bgcolor="#FFFFFF" text="#000000" link="#999999" vlink="#990000" alink="#666666">

<?
  $cur_page="terma_and_conditions";
  require("config.php");
  include($styles_file); 
?>
<p>

<?
include($header_file); 
?>

<table border="0" cellpadding="0" cellspacing="0" width="100%"><tr><td valign="top" width="1%"><font face="Arial, Arial, Helvetica">
<p>&nbsp;</p>
<p>
&nbsp;</p>
</font></td><td valign="top" width="24"></td><td valign="top"><font face="Arial, Arial, Helvetica">
<p><font size="4">Terms and Conditions for ONLINE-CSR service</font></p>
<p><font face="Arial">ONLINE-CSR</font>, Inc. is an independent 
company who specializes in the retrieval of records and the placing of orders 
for the Regional Bell Operating Companies (RBOCs) </p>
<p><font face="Arial">ONLINE-CSR</font> is a fee based service.&nbsp; 
The fees for the service have been established by your <font face="Arial">
ONLINE-CSR</font><sup> </sup>agent or directly by <font face="Arial">ONLINE-CSR</font> 
You will be billed by your agent or <font face="Arial">ONLINE-CSR</font> 
after your service has been set up.</p>
<p>You may cancel the service within the first 10 days and you will not be 
charged.</p>

</font></td></tr></table>

<?
 $isLogin = 1;
 include($footer_file); 
?>
</body>

</html>