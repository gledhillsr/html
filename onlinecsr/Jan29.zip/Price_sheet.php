<?
/********************************************************************/
/* do NOT edit the .php file, because it is a COPY of the .HTM file */
/* so others can use front page as an editor.                       */
/********************************************************************/
?>
<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Price Sheet</title>
<?
  $cur_page="Price_sheet";
  require("config.php");
  include($styles_file); 
?>
</head>

<body bgcolor="#FFFFFF" text="#000000" link="#999999" vlink="#990000" alink="#666666">
<?
include($header_file);  //note: don't specify "$page_title"
?>

<table border="0" cellpadding="0" cellspacing="0" width="100%"><tr><td valign="top" width="1%"><font face="Arial, Arial, Helvetica">


<p>&nbsp;</p>


<p>
&nbsp;</p>

</font></td><td valign="top" width="24"></td><td valign="top"><font face="Arial, Arial, Helvetica">
<p align="center"><font size="6" face="Arial">Pricing Sheet - Agents Cost</font></p>
<p><font face="Arial"><b>Set up fee</b> $100.00 ($200.00 List) No exceptions</font></p>
<p><font face="Arial"><b>Basic Service</b> You sell it at your cost, 20% 
commission or 50% commission</font></p>
</font><table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="91%" id="AutoNumber1" bordercolordark="#666666" bordercolorlight="#CCCCCC">
  <tr>
    <td width="13%"><font face="Arial, Arial, Helvetica">
    <p align="center"><font size="2" face="Arial"><b>20% 
    Commission</b></font></font></td>
    <td width="10%" align="center" bgcolor="#E9E9E9"><font face="Arial, Arial, Helvetica">
    <font size="2" face="Arial">Agent Cost</font></font></td>
    <td width="11%" align="center" bgcolor="#E9E9E9"><font face="Arial, Arial, Helvetica">
    <font size="2" face="Arial">Customer Price</font></font></td>
    <td width="10%" align="center"><font face="Arial, Arial, Helvetica"><font size="2" face="Arial">Agent Cost</font></font></td>
    <td width="11%" align="center"><font face="Arial, Arial, Helvetica"><font size="2" face="Arial">Customer Price</font></font></td>
    <td width="2%" align="center"><font face="Arial, Arial, Helvetica"><font size="2" face="Arial">Agent Cost</font></font></td>
    <td width="11%" align="center"><font face="Arial, Arial, Helvetica"><font size="2" face="Arial">Customer Price</font></font></td>
    <td width="2%" align="center"><font face="Arial, Arial, Helvetica"><font size="2" face="Arial">Agent Cost</font></font></td>
    <td width="4%" align="center"><font face="Arial, Arial, Helvetica"><font size="2" face="Arial">Customer Price</font></font></td>
  </tr>
  <tr>
    <td width="13%" align="center"><font face="Arial, Arial, Helvetica"><font size="2" face="Arial">Qty of CSRs</font></font></td>
    <td width="21%" colspan="2" align="center" bgcolor="#E9E9E9"><font face="Arial, Arial, Helvetica">
    <font size="2" face="Arial">2 look-ups</font></font></td>
    <td width="23%" colspan="2" align="center"><font face="Arial, Arial, Helvetica"><font size="2" face="Arial">3 
    look-ups</font></font></td>
    <td width="25%" colspan="2" align="center"><font face="Arial, Arial, Helvetica"><font size="2" face="Arial">4 
    look-ups</font></font></td>
    <td width="31%" colspan="2" align="center"><font face="Arial, Arial, Helvetica"><font size="2" face="Arial">6 
    look-ups</font></font></td>
  </tr>
  <tr>
    <td width="13%" align="center"><font face="Arial, Arial, Helvetica"><font size="2" face="Arial">1-24</font></font></td>
    <td width="10%" align="center" bgcolor="#E9E9E9"><font face="Arial, Arial, Helvetica"><font face="Arial">$15.00</font></font></td>
    <td width="11%" align="center" bgcolor="#E9E9E9"><font face="Arial, Arial, Helvetica"><font face="Arial">$18.75</font></font></td>
    <td width="10%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$22.50</font></font></td>
    <td width="11%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$28.13</font></font></td>
    <td width="10%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$30.00</font></font></td>
    <td width="13%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$37.50</font></font></td>
    <td width="10%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$45.00</font></font></td>
    <td width="13%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$56.25</font></font></td>
  </tr>
  <tr>
    <td width="13%" align="center"><font face="Arial, Arial, Helvetica"><font size="2" face="Arial">25-199</font></font></td>
    <td width="10%" align="center" bgcolor="#E9E9E9"><font face="Arial, Arial, Helvetica"><font face="Arial">$12.00</font></font></td>
    <td width="11%" align="center" bgcolor="#E9E9E9"><font face="Arial, Arial, Helvetica"><font face="Arial">$15.00</font></font></td>
    <td width="10%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$18.00</font></font></td>
    <td width="11%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$22.50</font></font></td>
    <td width="10%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$24.00</font></font></td>
    <td width="13%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$30.00</font></font></td>
    <td width="10%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$36.00</font></font></td>
    <td width="13%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$45.00</font></font></td>
  </tr>
  <tr>
    <td width="13%" align="center"><font face="Arial, Arial, Helvetica"><font size="2" face="Arial">200-399</font></font></td>
    <td width="10%" align="center" bgcolor="#E9E9E9"><font face="Arial, Arial, Helvetica"><font face="Arial">$10.00</font></font></td>
    <td width="11%" align="center" bgcolor="#E9E9E9"><font face="Arial, Arial, Helvetica"><font face="Arial">$12.50</font></font></td>
    <td width="10%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$15.00</font></font></td>
    <td width="11%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$18.75</font></font></td>
    <td width="10%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$20.00</font></font></td>
    <td width="13%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$25.00</font></font></td>
    <td width="10%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$30.00</font></font></td>
    <td width="13%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$37.50</font></font></td>
  </tr>
  <tr>
    <td width="13%" align="center"><font face="Arial, Arial, Helvetica"><font size="2" face="Arial">Over 400</font></font></td>
    <td width="10%" align="center" bgcolor="#E9E9E9"><font face="Arial, Arial, Helvetica"><font face="Arial">$8.00</font></font></td>
    <td width="11%" align="center" bgcolor="#E9E9E9"><font face="Arial, Arial, Helvetica"><font face="Arial">$10.00</font></font></td>
    <td width="10%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$12.00</font></font></td>
    <td width="11%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$15.00</font></font></td>
    <td width="10%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$16.00</font></font></td>
    <td width="13%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$20.00</font></font></td>
    <td width="10%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$24.00</font></font></td>
    <td width="13%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$30.00</font></font></td>
  </tr>
</table><font face="Arial, Arial, Helvetica">
<p>&nbsp; </p>
</font><table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="91%" id="AutoNumber1" bordercolordark="#666666" bordercolorlight="#CCCCCC">
  <tr>
    <td width="15%"><font face="Arial, Arial, Helvetica">
    <p align="center"><b><font size="2" face="Arial">50%</font></b><font size="2" face="Arial">(standard)</font><b><font size="2" face="Arial"> 
    Commission</font></b></font></td>
    <td width="8%" align="center" bgcolor="#E9E9E9"><font face="Arial, Arial, Helvetica"><font size="2" face="Arial">
    Agent Cost</font></font></td>
    <td width="12%" align="center" bgcolor="#E9E9E9"><font face="Arial, Arial, Helvetica">
    <font size="2" face="Arial">Customer Price</font></font></td>
    <td width="10%" align="center"><font face="Arial, Arial, Helvetica"><font size="2" face="Arial">Agent Cost</font></font></td>
    <td width="11%" align="center"><font face="Arial, Arial, Helvetica"><font size="2" face="Arial">Customer Price</font></font></td>
    <td width="1%" align="center"><font face="Arial, Arial, Helvetica"><font size="2" face="Arial">Agent Cost</font></font></td>
    <td width="11%" align="center"><font face="Arial, Arial, Helvetica"><font size="2" face="Arial">Customer Price</font></font></td>
    <td width="2%" align="center"><font face="Arial, Arial, Helvetica"><font size="2" face="Arial">Agent Cost</font></font></td>
    <td width="4%" align="center"><font face="Arial, Arial, Helvetica"><font size="2" face="Arial">Customer Price</font></font></td>
  </tr>
  <tr>
    <td width="15%" align="center"><font face="Arial, Arial, Helvetica"><font size="2" face="Arial">Qty of CSRs</font></font></td>
    <td width="20%" colspan="2" align="center" bgcolor="#E9E9E9"><font face="Arial, Arial, Helvetica">
    <font size="2" face="Arial">2 look-ups</font></font></td>
    <td width="23%" colspan="2" align="center"><font face="Arial, Arial, Helvetica"><font size="2" face="Arial">3 
    look-ups</font></font></td>
    <td width="24%" colspan="2" align="center"><font face="Arial, Arial, Helvetica"><font size="2" face="Arial">4 
    look-ups</font></font></td>
    <td width="31%" colspan="2" align="center"><font face="Arial, Arial, Helvetica"><font size="2" face="Arial">6 
    look-ups</font></font></td>
  </tr>
  <tr>
    <td width="15%" align="center"><font face="Arial, Arial, Helvetica"><font size="2" face="Arial">1-24</font></font></td>
    <td width="8%" align="center" bgcolor="#E9E9E9"><font face="Arial, Arial, Helvetica"><font face="Arial">$15.00</font></font></td>
    <td width="12%" align="center" bgcolor="#E9E9E9"><font face="Arial, Arial, Helvetica"><font face="Arial">$30.00</font></font></td>
    <td width="10%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$22.50</font></font></td>
    <td width="11%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$45.00</font></font></td>
    <td width="9%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$30.00</font></font></td>
    <td width="13%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$60.00</font></font></td>
    <td width="10%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$45.00</font></font></td>
    <td width="13%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$90.00</font></font></td>
  </tr>
  <tr>
    <td width="15%" align="center"><font face="Arial, Arial, Helvetica"><font size="2" face="Arial">25-199</font></font></td>
    <td width="8%" align="center" bgcolor="#E9E9E9"><font face="Arial, Arial, Helvetica"><font face="Arial">$12.00</font></font></td>
    <td width="12%" align="center" bgcolor="#E9E9E9"><font face="Arial, Arial, Helvetica"><font face="Arial">$24.00</font></font></td>
    <td width="10%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$18.00</font></font></td>
    <td width="11%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$36.000</font></font></td>
    <td width="9%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$24.00</font></font></td>
    <td width="13%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$48.00</font></font></td>
    <td width="10%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$36.00</font></font></td>
    <td width="13%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$72.00</font></font></td>
  </tr>
  <tr>
    <td width="15%" align="center"><font face="Arial, Arial, Helvetica"><font size="2" face="Arial">200-399</font></font></td>
    <td width="8%" align="center" bgcolor="#E9E9E9"><font face="Arial, Arial, Helvetica"><font face="Arial">$10.00</font></font></td>
    <td width="12%" align="center" bgcolor="#E9E9E9"><font face="Arial, Arial, Helvetica"><font face="Arial">$20.00</font></font></td>
    <td width="10%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$15.00</font></font></td>
    <td width="11%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$30.00</font></font></td>
    <td width="9%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$20.00</font></font></td>
    <td width="13%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$40.00</font></font></td>
    <td width="10%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$30.00</font></font></td>
    <td width="13%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$60.00</font></font></td>
  </tr>
  <tr>
    <td width="15%" align="center"><font face="Arial, Arial, Helvetica"><font size="2" face="Arial">Over 400</font></font></td>
    <td width="8%" align="center" bgcolor="#E9E9E9"><font face="Arial, Arial, Helvetica"><font face="Arial">$8.00</font></font></td>
    <td width="12%" align="center" bgcolor="#E9E9E9"><font face="Arial, Arial, Helvetica"><font face="Arial">$16.00</font></font></td>
    <td width="10%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$12.00</font></font></td>
    <td width="11%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$24.00</font></font></td>
    <td width="9%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$16.00</font></font></td>
    <td width="13%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$32.00</font></font></td>
    <td width="10%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$24.00</font></font></td>
    <td width="13%" align="center"><font face="Arial, Arial, Helvetica"><font face="Arial">$48.00</font></font></td>
  </tr>
</table><font face="Arial, Arial, Helvetica">
<p><font face="Arial"><b>Labor</b> The agents cost for labor is $50.00 per hour.&nbsp; 
The suggested client price is $80.00</font></p>
<p><font face="Arial"><b>Extra CSR Look-ups</b>&nbsp; The price for an addition 
CSR look-up is $10.00 per CSR.&nbsp; You can leave the cost to the client at 
$10.00 or mark it up as you like.<br>
<br>
&nbsp;</font></p>

</font></td></tr></table>

<?
 $isLogin = 1;
 include($footer_file); 
?>

</body>
</html>