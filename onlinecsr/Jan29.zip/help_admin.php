<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!-- saved from url=(0022)http://internet.e-mail --><HTML><HEAD><TITLE>HELP SCREEN</TITLE>
<META http-equiv=Content-Language content=en-us>
<META content="Microsoft FrontPage 5.0" name=GENERATOR>
<META content=FrontPage.Editor.Document name=ProgId>
<META http-equiv=Content-Type content="text/html; charset=windows-1252"></HEAD>
<BODY>
<P>&nbsp;</P>
<P align=center><B><FONT face=Arial color=#ff0000>HELP SCREEN (User 
Manager)</FONT></B><BR><img border="0" src="images/help_user_mgr.jpg" width="834" height="281"></P>
<P align=left><FONT face=Arial><B><FONT color=#ff0000>1) New User</FONT></B> 
This link will take you to a new page where you will add a user to your account.<BR><FONT color=#ff0000><B>
2) Line Inventory</B></FONT> This button takes you back to the main Line 
Inventory page.<BR><B><FONT color=#ff0000>3) Adds, Move &amp; Changes</FONT></B> 
This link will take you to the page where you make add services r make changes 
to existing services.<BR><B><FONT color=#ff0000>4) Edit</FONT></B> This button 
allows you to change or delete each user in your system.<BR><B><FONT color=#ff0000>
5) Login Name</FONT></B> This is the login name each individual is assigned by 
the system administrator.&nbsp; This field can not be modified.<BR><B><FONT color=#ff0000>
6) Password</FONT></B> The password is set by each user when they login for the 
first time.<BR><B><FONT color=#ff0000>7) Customer ID</FONT></B> Internally all 
your files are in this folder. This field can not be modified.<BR><B><FONT color=#ff0000>
8) </FONT></B><font color="#FF0000"><b>User Name</b></font> This is the full 
name of the user.<BR><B><FONT color=#ff0000>9) Admin</FONT></B> This field show 
who has admin privileges.&nbsp; Only those with admin privileges can view this 
page<BR><B><FONT color=#ff0000>10) </FONT></B><font color="#FF0000"><b>Notify 
About Logins</b></font> When anyone assigned to your account logs in to the 
system those who are marked here will be notified by email.<BR><FONT 
color=#ff0000><B>11) Notify About Changes</B></FONT> When there are adds moves 
and changes made on your account, who do you want to be notified.<BR><B><FONT color=#ff0000>
12) Department</FONT></B> If you have several people with access to your account 
when an email is generated the department is also mentioned in the email to help 
you associate where the request/order came from.<BR><B><FONT color=#ff0000>13) 
Email</FONT></B> The email address of this individual.<BR><B><FONT color=#ff0000>
14) Phone </FONT></B>&nbsp;The phone number of this individual.<BR><FONT color=#ff0000><B>
15) Mobile</B></FONT> The cell phone number of this individual.<BR><B><FONT color=#ff0000>
16) Access Count</FONT></B> This shows you how many times this person has logged 
in to the system.<BR>&nbsp;</FONT></P><BR><BR><BR>
<FORM name=demo action="<? echo $SCRIPT_NAME ?>" method=post>
<P align=center><INPUT onclick='window.location="admin.php"' type=button value="Return to User Manager" name=B2> 
</P></FORM></BODY></HTML>